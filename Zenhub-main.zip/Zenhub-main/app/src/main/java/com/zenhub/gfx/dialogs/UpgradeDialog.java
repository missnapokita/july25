package com.zenhub.gfx.dialogs;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.elfilibustero.injector.Injector;
import com.elfilibustero.injector.enums.InjectType;
import com.elfilibustero.mlbbdbc.models.UpgradeSkin;
import com.elfilibustero.mlbbdbc.models.UpgradeSkin.Data;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zenhub.gfx.R;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDialog;
import com.zenhub.gfx.databinding.HeroesSkinListItemBinding;
import com.zenhub.gfx.databinding.InjectDialogBinding;
import com.zenhub.gfx.databinding.UpgradeDialogBinding;
import com.zenhub.gfx.utils.Config;
import com.zenhub.gfx.utils.SketchwareUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class UpgradeDialog extends BottomSheetDialogFragment {

    private UpgradeDialogBinding binding;

    private static final String UPGRADE_SKIN = "upgrade_skin";

    public UpgradeDialog() {
        // Required empty public constructor
    }

    public static UpgradeDialog newInstance(String param) {
        UpgradeDialog fragment = new UpgradeDialog();
        Bundle args = new Bundle();
        args.putString(UPGRADE_SKIN, param);
        fragment.setArguments(args);
        return fragment;
    }

    private BaseActivity activity;

    private HashMap<String, Object> upgrade_skin = new HashMap<>();
    private Injector injector;
    private UpgradeSkin skin;

    private List<Data> datas = new ArrayList<>();

    private ListAdapter adapter;

    @NonNull
    @Override
    public View onCreateView(
            @NonNull LayoutInflater _inflater,
            @Nullable ViewGroup _container,
            @Nullable Bundle _savedInstanceState) {
        binding = UpgradeDialogBinding.inflate(_inflater, _container, false);
        initialize();
        return binding.getRoot();
    }

    private void initialize() {
        if (getActivity() instanceof BaseActivity baseActivity) {
            this.activity = baseActivity;
        }
        if (getArguments() != null) {
            upgrade_skin =
                    new Gson()
                            .fromJson(
                                    getArguments().getString(UPGRADE_SKIN),
                                    new TypeToken<HashMap<String, Object>>() {}.getType());
        }

        adapter = new ListAdapter();

        Gson gson = new Gson();
        String skinJson = gson.toJson(upgrade_skin.get("skin"));
        skin = gson.fromJson(skinJson, UpgradeSkin.class);
        binding.skinName.setText(skin.getSkinName());
        Glide.with(getContext())
                .load(Uri.parse(skin.getImage()))
                .placeholder(R.drawable.placeholder)
                .into(binding.portrait);
        String dataString = gson.toJson(upgrade_skin.get("data"));
        datas = gson.fromJson(dataString, new TypeToken<List<Data>>() {}.getType());
        binding.list.setAdapter(adapter);
        adapter.submitList(datas);

        binding.backup.setOnClickListener(
                view -> {
                    if (listener != null) {
                        if (listener.permissionGranted()) {
                            BaseDialog dialog = new BaseDialog(getActivity());
                            dialog.setTitle("Notice!");
                            dialog.setMessage(
                                    "Are you sure you want to inject the backup skin of "
                                            + skin.getSkinName()
                                            + "?\n\nClick \"Inject\" to continue.",
                                    true);
                            dialog.setPositiveButton(
                                    "Inject",
                                    v -> {
                                        inject(null, skin.getScript());
                                        dialog.dismiss();
                                    });
                            dialog.setNegativeButton(
                                    "Cancel",
                                    v -> {
                                        dialog.dismiss();
                                    });
                            dialog.show();
                        } else {
                            listener.onRequestPermission();
                        }
                    }
                });
    }

    public interface RequestPermissionListener {

        boolean permissionGranted();

        void onRequestPermission();
    }

    private RequestPermissionListener listener;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof RequestPermissionListener) {
            listener = (RequestPermissionListener) context;
        } else {
            throw new RuntimeException(
                    context.toString() + " must implement RequestPermissionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Override
    public int getTheme() {
        return R.style.CustomBottomSheetDialogTheme;
    }

    public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder> {

        List<Data> _data;

        public ListAdapter() {
            _data = new ArrayList<>();
        }

        public void submitList(List<Data> _arr) {
            DiffUtil.DiffResult diffResult =
                    DiffUtil.calculateDiff(
                            new DiffUtil.Callback() {
                                @Override
                                public int getOldListSize() {
                                    return _data.size();
                                }

                                @Override
                                public int getNewListSize() {
                                    return _arr.size();
                                }

                                @Override
                                public boolean areItemsTheSame(int old, int newPos) {
                                    return Objects.equals(_data.get(old), _arr.get(newPos));
                                }

                                @Override
                                public boolean areContentsTheSame(int old, int newPos) {
                                    return Objects.equals(_data.get(old), _arr.get(newPos));
                                }
                            });

            _data.clear();
            _data.addAll(_arr);
            diffResult.dispatchUpdatesTo(this);
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ViewHolder(
                    HeroesSkinListItemBinding.inflate(
                            LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            _holder.bind(_data.get(_position));
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            HeroesSkinListItemBinding binding;

            public ViewHolder(HeroesSkinListItemBinding v) {
                super(v.getRoot());
                binding = v;
            }

            public void bind(Data skin) {
                binding.title.setText(skin.getName());
                Glide.with(requireContext())
                        .load(Uri.parse(skin.getPortrait()))
                        .placeholder(R.drawable.placeholder)
                        .into(binding.portrait);

                itemView.setOnClickListener(
                        view -> {
                            if (listener != null) {
                                if (listener.permissionGranted()) {
                                    BaseDialog dialog = new BaseDialog(getActivity());
                                    dialog.setTitle("Notice!");
                                    dialog.setMessage(
                                            "Are you sure you want to inject "
                                                    + skin.getName()
                                                    + " skin?\n\nClick \"Inject\" to continue.",
                                            true);
                                    dialog.setPositiveButton(
                                            "Inject",
                                            v -> {
                                                inject(skin, skin.getScript());
                                                dialog.dismiss();
                                            });
                                    dialog.setNegativeButton(
                                            "Cancel",
                                            v -> {
                                                dialog.dismiss();
                                            });
                                    dialog.show();
                                } else {
                                    listener.onRequestPermission();
                                }
                            }
                        });
            }
        }
    }

    private void inject(Data data, String script) {
        var injector = new Injector(getActivity());
        injector.setPackageName("com.mobile.legends");
        injector.setInjectType(InjectType.fromType(Config.getPermission()));
        injector.setCallback(
                new Injector.Callback() {
                    BaseDialog dialog = new BaseDialog(getActivity());
                    InjectDialogBinding dialogBinding =
                            InjectDialogBinding.inflate(getLayoutInflater());

                    @Override
                    public void onStart() {
                        dialog.setView(dialogBinding.getRoot());
                        dialog.setTitle(data != null ? "Upgrading skin..." : "Restoring skin...");
                        if (data != null) {
                            dialogBinding.titleContainer.setVisibility(View.VISIBLE);
                            dialogBinding.message.setText(
                                    "Upgrading from "
                                            + skin.getSkinName()
                                            + " to "
                                            + data.getName()
                                            + "...");
                        } else {
                            dialogBinding.titleContainer.setVisibility(View.GONE);
                        }
                        dialog.setCancelable(false);
                        dialog.show();
                    }

                    @Override
                    public void onFetching(int _progress) {
                        dialogBinding.progress.setProgress(_progress);
                    }

                    @Override
                    public void onInjecting(int _progress) {
                        dialogBinding.progress.setProgress(_progress);
                    }

                    @Override
                    public void onComplete(Injector.InjectResult _result) {
                        String _errorMessage =
                                _result.getException() != null
                                        ? _result.getException().getMessage()
                                        : "";
                        if (_result.isSuccess()) {
                            SketchwareUtil.showMessage(
                                    requireContext(),
                                    data != null
                                            ? "Upgrading successfully"
                                            : "Restoring successfully");
                            if (activity != null) {
                                activity.showInterstitialAd();
                            }
                        } else {
                            SketchwareUtil.showMessage(requireContext(), _errorMessage);
                        }
                        dialog.dismiss();
                    }
                });
        injector.inject(script);
    }
}
