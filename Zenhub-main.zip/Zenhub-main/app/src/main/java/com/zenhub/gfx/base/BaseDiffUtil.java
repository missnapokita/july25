package com.zenhub.gfx.base;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;
import java.util.List;
import java.util.Objects;

public class BaseDiffUtil extends DiffUtil.Callback {
    List<?> oldList;
    List<?> newList;

    public BaseDiffUtil(List<?> newList, List<?> oldList) {
        this.newList = newList;
        this.oldList = oldList;
    }

    @Override
    public int getOldListSize() {
        return oldList.size();
    }

    @Override
    public int getNewListSize() {
        return newList.size();
    }

    @Override
    public boolean areItemsTheSame(int old, int newPos) {
        return Objects.equals(oldList.get(old), newList.get(newPos));
    }

    @Override
    public boolean areContentsTheSame(int old, int newPos) {
        return Objects.equals(oldList.get(old), newList.get(newPos));
    }

    @Nullable
    @Override
    public Object getChangePayload(int oldItemPosition, int newItemPosition) {
        return super.getChangePayload(oldItemPosition, newItemPosition);
    }
}
