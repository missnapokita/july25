package com.zenhub.gfx.libs.progress;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import com.zenhub.gfx.R;

public class ArcProgressBar extends View {
	
	private Paint arcPaint;
	private Paint textPaint;
	private int progress;
	private int maxProgress;
	private int arcThickness;
	private String text;
	
	public ArcProgressBar(Context context) {
		super(context);
		init();
	}
	
	public ArcProgressBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}
	
	public ArcProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		init();
	}
	
	private void init() {
		arcPaint = new Paint();
		arcPaint.setAntiAlias(true);
		arcPaint.setStyle(Paint.Style.STROKE);
		arcPaint.setStrokeCap(Paint.Cap.ROUND);
		
		textPaint = new Paint();
		textPaint.setAntiAlias(true);
		textPaint.setColor(Color.parseColor("#E0E0E0"));
		textPaint.setTextSize(50);
		
		progress = 0;
		maxProgress = 100;
		arcThickness = 20;
		text = "0%";
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		
		int width = getWidth();
		int height = getHeight();
		
		int diameter = Math.min(width, height);
		int radius = diameter / 2;
		int centerX = width / 2;
		int centerY = height / 2;
		
		float angle = 360f * progress / maxProgress;
		
		arcPaint.setStrokeWidth(arcThickness);
		arcPaint.setColor(getResources().getColor(R.color.colorAccent));
		
		// draw the arc
		canvas.drawArc(centerX - radius + arcThickness / 2,
		centerY - radius + arcThickness / 2,
		centerX + radius - arcThickness / 2,
		centerY + radius - arcThickness / 2,
		-90, angle, false, arcPaint);
		
		// draw text
		Rect bounds = new Rect();
		textPaint.getTextBounds(text, 0, text.length(), bounds);
		int textWidth = bounds.width();
		int textHeight = bounds.height();
		canvas.drawText(text, centerX - textWidth / 2, centerY + textHeight / 2, textPaint);
	}
	
	public void setProgress(int progress) {
		this.progress = progress;
		text = progress + "%";
		invalidate();
	}
	
	public void setMax(int maxProgress) {
		this.maxProgress = maxProgress;
	}
	
	public void setArcThickness(int arcThickness) {
		this.arcThickness = arcThickness;
		invalidate(); // redraw the view
	}
	
	public void setTextColor(int color) {
		textPaint.setColor(color);
		invalidate(); // redraw the view
	}
	
	public void setTextSize(float size) {
		textPaint.setTextSize(size);
		invalidate(); // redraw the view
	}
}
