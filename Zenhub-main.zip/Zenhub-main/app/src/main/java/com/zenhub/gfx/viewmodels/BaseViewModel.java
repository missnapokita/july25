package com.zenhub.gfx.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class BaseViewModel extends ViewModel {

    private final MutableLiveData<Boolean> loadedAds = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> showAds = new MutableLiveData<>(false);

    public LiveData<Boolean> isLoadedAds() {
        return loadedAds;
    }

    public void setLoadedAds(boolean loaded) {
        this.loadedAds.setValue(loaded);
    }

    public LiveData<Boolean> isShowAds() {
        return showAds;
    }

    public void setShowAds(boolean loaded) {
        this.showAds.setValue(loaded);
    }
}
