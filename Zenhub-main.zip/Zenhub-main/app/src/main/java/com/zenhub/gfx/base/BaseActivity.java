package com.zenhub.gfx.base;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.lifecycle.ViewModelProvider;

import com.blankj.utilcode.util.ToastUtils;
import com.elfilibustero.injector.enums.InjectType;
import com.elfilibustero.injector.utils.Constants;
import com.elfilibustero.mlbbdbc.models.*;
import com.elfilibustero.mlbbdbc.models.HeroResponse.Hero;
import com.elfilibustero.skintag.SkinTag;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.zenhub.gfx.BuildConfig;
import com.zenhub.gfx.R;
import com.zenhub.gfx.models.AdUnit;
import com.zenhub.gfx.tools.DataRepository;
import com.zenhub.gfx.utils.Config;
import com.zenhub.gfx.utils.ShizukuUtil;
import com.zenhub.gfx.utils.SketchwareUtil;
import com.zenhub.gfx.viewmodels.BaseViewModel;

import rikka.shizuku.Shizuku;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class BaseActivity extends AppCompatActivity {

    private static BaseActivity instance;
    private WeakReference<Context> ctx;

    private ActivityResultLauncher<Intent> openDocumentTreeLauncher;

    private final Shizuku.OnRequestPermissionResultListener listener =
            (requestCode, grantResult) -> {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    SketchwareUtil.showMessage(this, "Permission denied");
                }
            };

    private BaseViewModel baseViewModel;

    protected InterstitialAd interstitialAds;

    private static final String TAG = "BaseActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        super.onCreate(savedInstanceState);
        baseViewModel = new ViewModelProvider(this).get(BaseViewModel.class);
        instance = this;
        ctx = new WeakReference<>(this);
        initialize();
    }

    private void initialize() {
        Shizuku.addRequestPermissionResultListener(listener);
        openDocumentTreeLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                Intent data = result.getData();
                                if (data != null && data.getData() != null) {
                                    Uri mUri = data.getData();
                                    if (!Uri.decode(mUri.toString()).endsWith(":")) {
                                        var mFile = DocumentFile.fromTreeUri(this, mUri);
                                        int takeFlags =
                                                data.getFlags()
                                                        & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                                                                | Intent
                                                                        .FLAG_GRANT_WRITE_URI_PERMISSION);
                                        getContentResolver()
                                                .takePersistableUriPermission(mUri, takeFlags);
                                        Uri defaultUri =
                                                Uri.parse(
                                                        Constants.getExternalFilesDir(
                                                                InjectType.fromType(0),
                                                                "com.mobile.legends"));
                                        Uri newUri =
                                                Uri.parse(
                                                        Constants.getExternalFilesDir(
                                                                InjectType.fromType(1),
                                                                "com.mobile.legends"));
                                        if (isEqual(mFile.getUri(), defaultUri)) {
                                            Config.setPermission(0);
                                            ToastUtils.showShort("Permission granted");
                                        } else if (isEqual(mFile.getUri(), newUri)) {
                                            Config.setPermission(1);
                                            ToastUtils.showShort("Permission granted");
                                        } else {
                                            SketchwareUtil.showMessage(this, "Wrong path selected");
                                        }
                                    }
                                }
                            }
                        });
    }

    public boolean hasPermission() {
        switch (Config.getPermission()) {
            case 2 -> {
                return ShizukuUtil.isShizukuInstalled(this) && ShizukuUtil.isReady();
            }
            case 0 -> {
                Uri defaultUri =
                        Uri.parse(
                                Constants.getExternalFilesDir(
                                        InjectType.fromType(0), "com.mobile.legends"));
                return hasPermissionFor(this, defaultUri);
            }
            case 1 -> {
                Uri newUri =
                        Uri.parse(
                                Constants.getExternalFilesDir(
                                        InjectType.fromType(1), "com.mobile.legends"));
                return hasPermissionFor(this, newUri);
            }
            default -> {
                return false;
            }
        }
    }

    public boolean isEqual(Uri firstUri, Uri secondUri) {
        String first = android.provider.DocumentsContract.getTreeDocumentId(firstUri);
        String second = android.provider.DocumentsContract.getTreeDocumentId(secondUri);
        return second != null && first.equals(second);
    }

    public boolean isAccessible(Uri uri) {
        return getContentResolver().getType(uri) != null;
    }

    public boolean hasPermissionFor(Context context, Uri uri) {
        DocumentFile mFile = DocumentFile.fromTreeUri(context, uri);
        if (mFile.canRead() && mFile.canWrite()) {
            return true;
        }
        return false;
    }

    public void checkPermission() {
        var permission = Config.getPermission();
        var uri =
                Uri.parse(
                        Constants.getExternalFilesDir(
                                InjectType.fromType(permission), "com.mobile.legends"));
        switch (permission) {
            case 0, 1 -> {
                var dialog =
                        new BaseDialog(this)
                                .setTitle("Permission required")
                                .setMessage(getPermissionMessage());
                dialog.setPositiveButton(
                        "Allow",
                        v -> {
                            openDocumentTree("com.mobile.legends");
                            dialog.dismiss();
                        });
                dialog.setNegativeButton("Cancel", v -> dialog.dismiss());
                dialog.show();
            }
            case 2 -> ShizukuUtil.checkPermission(this, 1000);
        }
    }

    public void openDocumentTree(String packageName) {
        var intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.putExtra(
                android.provider.DocumentsContract.EXTRA_INITIAL_URI,
                Uri.parse(
                        Constants.getExternalFilesDir(
                                InjectType.fromType(Config.getPermission()), packageName)));
        openDocumentTreeLauncher.launch(intent);
    }

    public boolean _permissionsGranted() {
        return (androidx.core.content.ContextCompat.checkSelfPermission(
                                this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED
                && androidx.core.content.ContextCompat.checkSelfPermission(
                                this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED);
    }

    public static BaseActivity getInstance() {
        return instance;
    }

    public ArrayList<String> getHeroNames() {
        ArrayList<String> list = new ArrayList<>();
        var heroes = DataRepository.getInstance().getHeroes();
        if (heroes == null || heroes.isEmpty()) {
            return new ArrayList<>();
        }
        for (Hero hero : heroes) {
            list.add(hero.getName());
        }
        return list;
    }

    public int getSelectedRole(String role) {
        return switch (role) {
            case "Assassin" -> 0;
            case "Fighter" -> 1;
            case "Mage" -> 2;
            case "Marksman" -> 3;
            case "Support" -> 4;
            case "Tank" -> 5;
            default -> -1;
        };
    }

    public Hero getHeroFrom(final int _id) {
        var heroes = DataRepository.getInstance().getHeroes();
        if (heroes == null || heroes.isEmpty()) {
            return null;
        }
        for (Hero hero : heroes) {
            if (hero.getId() == _id) {
                return hero;
            }
        }
        return null;
    }

    public List<Skin> getSkinsOf(final int _id) {
        List<Skin> skins = new ArrayList<>();
        var temp = DataRepository.getInstance().getSkins();
        if (temp == null || temp.isEmpty()) {
            return new ArrayList<>();
        }
        for (Skin skin : temp) {
            if (skin.getHeroId() == _id) {
                skins.add(skin);
            }
        }
        if (!skins.isEmpty()) {
            skins.sort((s1, s2) -> Integer.compare(s1.getSkinId(), s2.getSkinId()));
        }
        return skins;
    }

    public List<Skin> findSkinsByCategory(int id, int category) {
        return getSkinsOf(id).stream()
                .filter(skin -> skin.getSkinCategory() == category)
                .collect(Collectors.toList());
    }

    public List<Skin> findSkinsByType(int id, int category, String type) {
        return findSkinsByCategory(id, category).stream()
                .filter(skin -> skin.getSkinType().toLowerCase().contains(type.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Skin> findCustomizeSkins(int id) {
        return getSkinsOf(id).stream()
                .filter(skin -> skin.getSkinCategory() != 0)
                .collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> findHeroDetailsById(int id) {
        var details = DataRepository.getInstance().getHeroDetails();
        if (details.containsKey(String.valueOf(id))) {
            return (Map<String, Object>) details.get(String.valueOf(id));
        }
        return new HashMap<>();
    }

    public ArrayList<HashMap<String, Object>> getSkinsByType(String role) {
        var skins = DataRepository.getInstance().getSkins();
        ArrayList<HashMap<String, Object>> skinList = new ArrayList<>();
        var heroes = DataRepository.getInstance().getHeroes();
        if (heroes == null || heroes.isEmpty()) {
            return new ArrayList<>();
        }
        heroes.sort(Comparator.comparing(Hero::getName));
        heroes.forEach(
                hero -> {
                    var detail = findHeroDetailsById(hero.getId());
                    if (detail.containsKey("type")) {
                        if (detail.get("type").toString().equalsIgnoreCase(role)) {
                            List<Skin> heroSkins = getSkinsOf(hero.getId());
                            if (heroSkins != null && !heroSkins.isEmpty()) {
                                HashMap<String, Object> map = new HashMap<>();
                                map.put("hero", hero);
                                map.put("skins", heroSkins);
                                skinList.add(map);
                            }
                        }
                    }
                });
        return skinList;
    }

    public ArrayList<HashMap<String, Object>> getSkinsByCategory(String role, int category) {
        ArrayList<HashMap<String, Object>> skinList = new ArrayList<>();
        var heroes = DataRepository.getInstance().getHeroes();
        if (heroes == null || heroes.isEmpty()) {
            return new ArrayList<>();
        }
        heroes.sort(Comparator.comparing(Hero::getName));
        heroes.forEach(
                hero -> {
                    var detail = findHeroDetailsById(hero.getId());
                    if (detail.containsKey("type")) {
                        if (detail.get("type").toString().equalsIgnoreCase(role)) {
                            List<Skin> heroSkins = new ArrayList<>();
                            if (category != 0) {
                                List<Skin> skins = getSkinsOf(hero.getId());
                                for (Skin skin : skins) {
                                    if (skin.getSkinType().equalsIgnoreCase("Backup")) {
                                        heroSkins.add(skin);
                                        break;
                                    }
                                }
                            }
                            heroSkins.addAll(findSkinsByCategory(hero.getId(), category));
                            if (heroSkins != null && !heroSkins.isEmpty() && heroSkins.size() > 1) {
                                HashMap<String, Object> map = new HashMap<>();
                                map.put("hero", hero);
                                map.put("skins", heroSkins);
                                skinList.add(map);
                            }
                        }
                    }
                });
        return skinList;
    }

    public ArrayList<HashMap<String, Object>> getSkinsOf(String role, int category, String type) {
        ArrayList<HashMap<String, Object>> skinList = new ArrayList<>();
        var heroes = DataRepository.getInstance().getHeroes();
        if (heroes == null || heroes.isEmpty()) {
            return new ArrayList<>();
        }
        heroes.sort(Comparator.comparing(Hero::getName));
        heroes.forEach(
                hero -> {
                    var detail = findHeroDetailsById(hero.getId());
                    if (detail.get("type").toString().equalsIgnoreCase(role)) {
                        List<Skin> heroSkins = new ArrayList<>();
                        if (category != 0) {
                            List<Skin> skins = getSkinsOf(hero.getId());
                            for (Skin skin : skins) {
                                if (skin.getSkinType().equalsIgnoreCase("Backup")) {
                                    heroSkins.add(skin);
                                    break;
                                }
                            }
                        }
                        heroSkins.addAll(findSkinsByType(hero.getId(), category, type));
                        if (heroSkins != null && !heroSkins.isEmpty() && heroSkins.size() > 1) {
                            HashMap<String, Object> map = new HashMap<>();
                            map.put("hero", hero);
                            map.put("skins", heroSkins);
                            skinList.add(map);
                        }
                    }
                });
        return skinList;
    }

    public List<BattleEffect> getBattleEffectsByType(int type) {
        var effects = DataRepository.getInstance().getEffects();
        if (effects == null || effects.isEmpty()) {
            return new ArrayList<>();
        }
        return effects.stream()
                .filter(skin -> skin.getType() == type)
                .sorted(Comparator.comparing(BattleEffect::isBackup).reversed())
                .collect(Collectors.toList());
    }

    public List<UpgradeSkin> getUpgradedSkinsOf(int heroId) {
        var skins = DataRepository.getInstance().getUpgradeSkins();

        if (skins == null || skins.isEmpty()) {
            return List.of();
        }

        return skins.stream()
                .filter(skin -> skin.getHeroId() == heroId)
                .sorted((s1, s2) -> Integer.compare(s1.getSkinId(), s2.getSkinId()))
                .collect(Collectors.toList());
    }

    public List<UpgradeSkin.Data> getUpgradedDataOf(int heroId, int skinId) {
        var skins = DataRepository.getInstance().getUpgradeSkinsData();

        if (skins == null || skins.isEmpty()) {
            return List.of();
        }

        return skins.stream()
                .filter(skin -> skin.getHeroId() == heroId && skin.getSkinId() == skinId)
                .sorted((s1, s2) -> Integer.compare(s1.getUpgradeId(), s2.getUpgradeId()))
                .collect(Collectors.toList());
    }

    public ArrayList<HashMap<String, Object>> getUpgradedSkins() {
        return getUpgradedSkinsOf(null);
    }

    public ArrayList<HashMap<String, Object>> getUpgradedSkinsOf(String role) {
        ArrayList<HashMap<String, Object>> skinList = new ArrayList<>();
        var heroes = DataRepository.getInstance().getHeroes();
        if (heroes == null || heroes.isEmpty()) {
            return new ArrayList<>();
        }
        heroes.sort(Comparator.comparing(Hero::getName));
        heroes.stream()
                .filter(
                        hero -> {
                            if (role == null || role.isEmpty()) {
                                return true;
                            }
                            var detail = findHeroDetailsById(hero.getId());
                            return detail.get("type").toString().equalsIgnoreCase(role);
                        })
                .forEach(
                        hero -> {
                            var upgradeSkins = getUpgradedSkinsOf(hero.getId());
                            if (upgradeSkins != null && !upgradeSkins.isEmpty()) {
                                ArrayList<HashMap<String, Object>> upgrades = new ArrayList<>();
                                upgradeSkins.forEach(
                                        skin -> {
                                            var upgradeData =
                                                    getUpgradedDataOf(
                                                            hero.getId(), skin.getSkinId());
                                            if (upgradeData != null && !upgradeData.isEmpty()) {
                                                var data = new HashMap<String, Object>();
                                                data.put("skin", skin);
                                                data.put("data", upgradeData);
                                                upgrades.add(data);
                                            }
                                        });
                                if (upgrades != null && !upgrades.isEmpty()) {
                                    var map = new HashMap<String, Object>();
                                    map.put("hero", hero);
                                    map.put("skins", upgrades);
                                    skinList.add(map);
                                }
                            }
                        });
        return skinList;
    }

    public int getSkinTagFrom(String iconName) {
        return SkinTag.getSkinTagFrom(iconName);
    }

    public void openUrl(String url) {
        try {
            Intent open = new Intent(Intent.ACTION_VIEW);
            open.setData(Uri.parse(url));
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(open);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    public void openApp(String packageName) {
        PackageManager pm = getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage(packageName);

        if (launchIntent != null) {
            startActivity(launchIntent);
        } else {
            redirectToPlayStore(packageName);
        }
    }

    private void redirectToPlayStore(String packageName) {
        try {
            startActivity(
                    new Intent(
                            Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName)));
        } catch (android.content.ActivityNotFoundException e) {
            startActivity(
                    new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(
                                    "https://play.google.com/store/apps/details?id="
                                            + packageName)));
        }
    }

    @Override
    protected void onDestroy() {
        ctx.clear();
        super.onDestroy();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    public String getPermissionMessage() {
        String externalFilesDirectory =
                String.format(Constants.EXTERNAL_FILES_DIRECTORY, "com.mobile.legends");
        String htmlText =
                "This app needs to access the <font color='#ff9800'>Internal storage/</font>"
                        + "<font color='#ff9800'>"
                        + externalFilesDirectory
                        + "</font>"
                        + " folder to perform a specific task. Please grant the necessary permission to continue. Click "
                        + "\"Use this folder\" on the next screen.";
        return htmlText;
    }

    public void showInterstitialAd() {
        showClaudeTip();

        loadInterstitialAd(com.zenhub.gfx.utils.Constants.AD_NAME_ROLE_ACTIVITY);
    }

    public void loadInterstitialAd(final String adFormat) {
        if (adFormat == null || adFormat.isEmpty()) return;

        AdRequest request = new AdRequest.Builder().build();
        String ad = AdUnit.getUnitIdByAdFormat(adFormat, BuildConfig.DEBUG);

        if (ad != null) {
            InterstitialAd.load(
                    this,
                    Objects.requireNonNull(ad),
                    request,
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            loadInterstitialAd(
                                    com.zenhub.gfx.utils.Constants.AD_NAME_ROLE_ACTIVITY);
                        }

                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            interstitialAds = interstitialAd;
                            interstitialAds.show(BaseActivity.this);
                        }
                    });
        }
    }

    public void setFullscreenInterstitial() {
        interstitialAds.setFullScreenContentCallback(
                new FullScreenContentCallback() {
                    @Override
                    public void onAdClicked() {
                        // Called when a click is recorded for an ad.
                        Log.d(TAG, "Ad was clicked.");
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when ad is dismissed.
                        // Set the ad reference to null so you don't show the ad a second time.
                        Log.d(TAG, "Ad dismissed fullscreen content.");
                        interstitialAds = null;
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when ad fails to show.
                        Log.e(TAG, "Ad failed to show fullscreen content.");
                        interstitialAds = null;
                    }

                    @Override
                    public void onAdImpression() {
                        // Called when an impression is recorded for an ad.
                        Log.d(TAG, "Ad recorded an impression.");
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when ad is shown.
                        Log.d(TAG, "Ad showed fullscreen content.");
                    }
                });
    }

    public void showClaudeTip() {
        try {
            var tips = getSharedPreferences("TIPS", 0);
            boolean show = tips.getBoolean("tip1", true);

            if (!show) return;

            var imageView = new ImageView(this);
            imageView.setLayoutParams(
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            (int) SketchwareUtil.getDip(getApplicationContext(), 300)));
            imageView.setImageResource(R.drawable.claude);

            var dialog = new BaseDialog(this);
            dialog.setTitle("Tips!");
            dialog.setMessage(
                    "Choose <font color='#ff9800'>MEDIUM</font>, <font color='#ff9800'>HIGH</font>, or <font color='#ff9800'>ULTRA</font> to make your injected skin work.");
            dialog.setView(imageView);
            dialog.setPositiveButton("Close", v -> dialog.dismiss());
            dialog.setDefaultButton(
                    "Don't show again",
                    v -> {
                        tips.edit().putBoolean("tip1", false).apply();
                        dialog.dismiss();
                    });

            dialog.show();
        } catch (Exception ginored) {

        }
    }
}
