package com.zenhub.gfx.utils;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import com.zenhub.gfx.utils.SketchwareUtil;

import org.lsposed.hiddenapibypass.HiddenApiBypass;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuProvider;
import rikka.shizuku.ShizukuRemoteProcess;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ShizukuUtil {

    public static boolean isReady() {
        return isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean isRunning() {
        return Shizuku.pingBinder();
    }

    public static String execute(Process process) throws InterruptedException, IOException {
        StringWriter output = new StringWriter();
        StringWriter errorOutput = new StringWriter();

        Thread outputThread = new Thread(() -> readStream(process.getInputStream(), output));
        Thread errorThread = new Thread(() -> readStream(process.getErrorStream(), errorOutput));

        outputThread.start();
        errorThread.start();

        outputThread.join();
        errorThread.join();

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IOException(
                    "Command execution failed with exit code: "
                            + exitCode
                            + "\n"
                            + errorOutput.toString());
        }
        return output.toString();
    }

    private static void readStream(InputStream inputStream, StringWriter output) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = reader.readLine()) != null) {
                synchronized (output) {
                    output.append(line).append("\n");
                }
            }
        } catch (IOException e) {
        }
    }

    public static boolean exists(String filePath, String fileName) throws Exception {
        var list = listDirectory(filePath);
        for (String file : list) {
            if (file.equals(fileName)) {
                return true;
            }
        }
        return false;
    }

    public static List<String> listDirectory(String directoryPath) throws Exception {
        ShizukuRemoteProcess process =
                newProcess(new String[] {"sh", "-c", "ls"}, null, directoryPath);
        if (process == null) {
            return new ArrayList<>();
        }
        return Arrays.asList(execute(process).split("\n"));
    }

    public static boolean unzip(String zipFile, String destDir) {
        try {
            ShizukuRemoteProcess process =
                    newProcess(
                            new String[] {
                                "sh", "-c", "unzip -o " + escapeFilePath(zipFile) + " -d " + destDir
                            },
                            null,
                            null);
            if (process == null) {
                return false;
            }
            File _zipFile = new File(zipFile);
            if (_zipFile.exists()) {
                _zipFile.delete();
            }
            process.waitFor();
            return true;
        } catch (InterruptedException ignored) {
            return false;
        }
    }

    public static boolean deleteFile(String filePath) throws IOException {
        try {
            ShizukuRemoteProcess process =
                    newProcess(new String[] {"sh", "-c", "rm " + filePath}, null, null);
            if (process != null) {
                int exitCode = process.waitFor();
                return exitCode == 0;
            }
        } catch (InterruptedException ignored) {
        }
        return false;
    }

    public static byte[] readFile(String filePath) throws IOException {
        try {
            ShizukuRemoteProcess process =
                    newProcess(new String[] {"sh", "-c", "cat " + filePath}, null, null);
            if (process != null) {
                InputStream inputStream = process.getInputStream();
                ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    byteStream.write(buffer, 0, bytesRead);
                }

                int exitCode = process.waitFor();

                if (exitCode == 0) {
                    return byteStream.toByteArray();
                }
            }
        } catch (InterruptedException ignored) {
        }
        return new byte[0];
    }

    public static boolean writeFile(String filePath, byte[] data) throws Exception {
        ShizukuRemoteProcess process =
                newProcess(new String[] {"sh", "-c", "cat > " + filePath}, null, null);
        if (process == null) {
            return false;
        }
        BufferedOutputStream outputStream = new BufferedOutputStream(process.getOutputStream());
        outputStream.write(data);
        outputStream.flush();
        outputStream.close();

        int exitCode = process.waitFor();

        return exitCode == 0;
    }

    public static boolean moveFile(String sourcePath, String directoryPath) {
        return copyFile(sourcePath, directoryPath, true);
    }

    public static boolean copyFile(String sourcePath, String directoryPath) {
        return copyFile(sourcePath, directoryPath, false);
    }

    public static boolean copyFile(String sourcePath, String directoryPath, boolean delete) {
        try {
            ShizukuRemoteProcess process =
                    newProcess(
                            new String[] {
                                "sh",
                                "-c",
                                "cp -r " + escapeFilePath(sourcePath) + " " + directoryPath
                            },
                            null,
                            null);
            if (process == null) {
                return false;
            }
            process.waitFor();
            if (delete) {
                File _sourcePath = new File(sourcePath);
                if (_sourcePath.exists()) {
                    _sourcePath.delete();
                }
            }
            return true;
        } catch (InterruptedException ignored) {
            return false;
        }
    }

    public static ShizukuRemoteProcess newProcess(String[] cmd, String[] env, String dir) {
        return (ShizukuRemoteProcess)
                HiddenApiBypass.invoke(Shizuku.class, null, "newProcess", cmd, env, dir);
    }

    private static String escapeFilePath(String filePath) {
        return filePath.replaceAll(" ", "\\\\ ");
    }

    @SuppressWarnings("deprecation")
    public static boolean isShizukuInstalled(Context context) {
        PackageManager packageManager = context.getPackageManager();
        List<ApplicationInfo> appList = packageManager.getInstalledApplications(0);

        for (ApplicationInfo applicationInfo : appList) {
            if (applicationInfo.packageName.equals(ShizukuProvider.MANAGER_APPLICATION_ID)) {
                return true;
            }
        }

        return false;
    }

    public static boolean checkPermission(Context context, int requestCode) {
        if (!isShizukuInstalled(context)) {
            SketchwareUtil.showMessage(context, "Shizuku is not installed");
            return false;
        }
        if (isReady()) {
            return true;
        }
        if (isRunning()) {
            if (Shizuku.isPreV11()) {
                ((Activity) context)
                        .requestPermissions(new String[] {ShizukuProvider.PERMISSION}, requestCode);
            } else {
                Shizuku.requestPermission(requestCode);
            }
        } else {
            SketchwareUtil.showMessage(context, "Shizuku is not running");
        }
        return false;
    }
}
