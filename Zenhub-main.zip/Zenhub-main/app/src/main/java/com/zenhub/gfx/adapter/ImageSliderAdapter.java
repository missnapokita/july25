package com.zenhub.gfx.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.SliderViewAdapter;
import java.util.ArrayList;
import java.util.List;

import com.zenhub.gfx.R;

public class ImageSliderAdapter extends SliderViewAdapter<ImageSliderAdapter.ViewHolder> {
	
	private Context context;
	private List<String> _data = new ArrayList<>();
	
	public ImageSliderAdapter(Context context) {
		this.context = context;
	}
	
	public void renewItems(List<String> _arr) {
		_data = _arr;
		notifyDataSetChanged();
	}
	
	public void deleteItem(int position) {
		_data.remove(position);
		notifyDataSetChanged();
	}
	
	public void addItem(String sliderItem) {
		_data.add(sliderItem);
		notifyDataSetChanged();
	}
	
	@Override
	public ViewHolder onCreateViewHolder(ViewGroup parent) {
		View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_slider, null);
		return new ViewHolder(inflate);
	}
	
	@Override
	public void onBindViewHolder(ViewHolder viewHolder, final int position) {
		String sliderItem = _data.get(position);
		Glide.with(viewHolder.itemView)
		.load(sliderItem).fitCenter()
        .placeholder(R.drawable.preload)
		.into(viewHolder.slider);
	}
	
	@Override
	public int getCount() {
		return _data.size();
	}
	
	class ViewHolder extends SliderViewAdapter.ViewHolder {
		
		ImageView slider;
		public ViewHolder(View itemView) {
			super(itemView);
			slider = itemView.findViewById(R.id.image_slider);
		}
	}
	
}
