package com.zenhub.gfx.activities;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.elfilibustero.mlbbdbc.models.BattleEffect;
import com.elfilibustero.mlbbdbc.models.Skin;
import com.google.gson.Gson;
import com.zenhub.gfx.R;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDialog;
import com.zenhub.gfx.databinding.HeroesSkinListItemBinding;
import com.zenhub.gfx.databinding.InjectHistoryBinding;
import com.zenhub.gfx.tools.HistoryRepository;

import java.util.ArrayList;
import java.util.List;

public class InjectHistoryActivity extends BaseActivity {

    private InjectHistoryBinding binding;

    private HistoryRepository repository;

    private List<Skin> skins = new ArrayList<>();
    private List<BattleEffect> effects = new ArrayList<>();

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = InjectHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();
        initializeLogic();
    }

    private void initialize() {
        var _toolbar = binding.Toolbar;
        setSupportActionBar(_toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        _toolbar.setNavigationOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _v) {
                        onBackPressed();
                    }
                });

        binding.Fab.setOnClickListener(
                view -> {
                    BaseDialog dialog = new BaseDialog(InjectHistoryActivity.this);
                    dialog.setTitle("Clean");
                    dialog.setMessage("Are you sure you want to clean the history?");
                    dialog.setPositiveButton(
                            "Yes",
                            v -> {
                                repository.saveSkins(new ArrayList<>());
                                repository.saveEffects(new ArrayList<>());
                                _loadSkins();
                                _loadEffects();
                                dialog.dismiss();
                            });
                    dialog.setNegativeButton(
                            "No",
                            v -> {
                                dialog.dismiss();
                            });
                    dialog.show();
                });

        ViewCompat.setOnApplyWindowInsetsListener(
                binding.Fab,
                (v, windowInsets) -> {
                    var insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
                    var mlp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                    mlp.leftMargin += insets.left;
                    mlp.bottomMargin += insets.bottom;
                    mlp.rightMargin += insets.right;
                    v.setLayoutParams(mlp);
                    return WindowInsetsCompat.CONSUMED;
                });
    }

    private void initializeLogic() {
        setTitle("Inject History");
        binding.Toolbar.setTitleTextColor(Color.WHITE);
        repository = new HistoryRepository(this);
        _loadSkins();
        _loadEffects();
    }

    @Override
    public void onResume() {
        super.onResume();
        _loadSkins();
        _loadEffects();
    }

    public void _loadSkins() {
        var skinList = binding.skinList;
        var empty_skin = binding.emptySkin;
        skins = repository.loadSkins();
        if (skins == null || skins.isEmpty()) {
            skinList.setVisibility(View.GONE);
            empty_skin.setVisibility(View.VISIBLE);
            empty_skin.setText("No skin history");
        } else {
            empty_skin.setVisibility(View.GONE);
            skinList.setVisibility(View.VISIBLE);
            skinList.setAdapter(new SkinListAdapter(skins));
        }
    }

    public void _loadEffects() {
        var fXList = binding.fXList;
        var empty_bfx = binding.emptyBfx;
        effects = repository.loadEffects();
        if (effects == null || effects.isEmpty()) {
            fXList.setVisibility(View.GONE);
            empty_bfx.setVisibility(View.VISIBLE);
            empty_bfx.setText("No battle effects history");
        } else {
            empty_bfx.setVisibility(View.GONE);
            fXList.setVisibility(View.VISIBLE);
            fXList.setAdapter(new FXListAdapter(effects));
        }
    }

    public class SkinListAdapter extends RecyclerView.Adapter<SkinListAdapter.ViewHolder> {

        List<Skin> _data;

        public SkinListAdapter(List<Skin> _arr) {
            _data = _arr;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ViewHolder(
                    HeroesSkinListItemBinding.inflate(
                            LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            _holder.bind(_data.get(_position));
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            HeroesSkinListItemBinding binding;

            public ViewHolder(HeroesSkinListItemBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }

            void bind(Skin skin) {
                var hero = findHeroDetailsById(skin.getHeroId());
                binding.title.setText(skin.getSkinName());
                Glide.with(getApplicationContext())
                        .load(Uri.parse(skin.getSkinPortrait()))
                        .placeholder(R.drawable.placeholder)
                        .into(binding.portrait);
                binding.skinTag.setImageResource(getSkinTagFrom(skin.getSkinType()));
                itemView.setOnClickListener(
                        view -> {
                            Intent intent = new Intent();
                            intent.setClass(getApplicationContext(), RoleActivity.class);
                            intent.putExtra("role", hero.get("type").toString());
                            intent.putExtra("history", new Gson().toJson(skin));
                            startActivity(intent);

                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        });
            }
        }
    }

    public class FXListAdapter extends RecyclerView.Adapter<FXListAdapter.ViewHolder> {

        List<BattleEffect> _data;

        public FXListAdapter(List<BattleEffect> _arr) {
            _data = _arr;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater _inflater = getLayoutInflater();
            View _v = _inflater.inflate(R.layout.battle_effect_list_item, null);
            RecyclerView.LayoutParams _lp =
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            _v.setLayoutParams(_lp);
            return new ViewHolder(_v);
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            View _view = _holder.itemView;

            final LinearLayout base = _view.findViewById(R.id.base);
            final com.google.android.material.card.MaterialCardView cardview1 =
                    _view.findViewById(R.id.cardview1);
            final TextView title = _view.findViewById(R.id.title);
            final FrameLayout linear1 = _view.findViewById(R.id.linear1);
            final ImageView imageview1 = _view.findViewById(R.id.imageview1);
            final View linear2 = _view.findViewById(R.id.linear2);

            RecyclerView.LayoutParams _lp =
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            _view.setLayoutParams(_lp);

            var effect = _data.get(_position);
            title.setText(effect.getName());
            Glide.with(getApplicationContext())
                    .load(Uri.parse(effect.getImage()))
                    .placeholder(R.drawable.default_placeholder)
                    .into(imageview1);

            cardview1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View _view) {
                            Intent intent = new Intent();
                            intent.setClass(getApplicationContext(), BattleEffectActivity.class);
                            intent.putExtra("effect", new Gson().toJson(effect));
                            intent.putExtra("name", effect.getName());
                            startActivity(intent);

                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        }
                    });
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View v) {
                super(v);
            }
        }
    }
}
