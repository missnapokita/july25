package com.zenhub.gfx.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.elfilibustero.mlbbdbc.models.Script;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.SnackbarUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.elfilibustero.injector.Injector;
import com.elfilibustero.injector.enums.InjectType;
import com.elfilibustero.mlbbdbc.models.Skin;
import com.elfilibustero.pagination.Paginate;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.appupdate.AppUpdateOptions;
import com.google.android.play.core.common.IntentSenderForResultStarter;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.smarteist.autoimageslider.SliderAnimations;
import com.thekhaeng.pushdownanim.PushDownAnim;
import com.zenhub.gfx.BuildConfig;
import com.zenhub.gfx.R;
import com.zenhub.gfx.adapter.ImageSliderAdapter;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDialog;
import com.zenhub.gfx.databinding.MainBinding;
import com.zenhub.gfx.libs.spannable.CustomTypefaceSpan;
import com.zenhub.gfx.libs.spannable.RoundedBackgroundSpan;
import com.zenhub.gfx.tools.DataRepository;
import com.zenhub.gfx.tools.HistoryRepository;
import com.zenhub.gfx.utils.Config;
import com.zenhub.gfx.utils.Constants;
import com.zenhub.gfx.utils.FileUtil;
import com.zenhub.gfx.utils.ShizukuUtil;
import com.zenhub.gfx.utils.SketchwareUtil;

import io.anyip.sdk.service.EndlessService;
import io.anyip.sdk.utils.ParamsArgus;
import io.anyip.sdk.utils.Preferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MainActivity extends BaseActivity {

    private MainBinding binding;

    private DrawerLayout _drawer;
    private ImageSliderAdapter sliderAdapter;
    private DataRepository dataRepository = DataRepository.getInstance();
    private HashMap<String, Object> map = new HashMap<>();
    private Injector injector;

    private ArrayList<String> sliderList = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> fx = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> roles = new ArrayList<>();

    private Intent intent = new Intent();
    private AlertDialog.Builder dialog;
    private Intent share = new Intent();

    private final EndlessService service = new EndlessService();

    private AppUpdateManager appUpdateManager;

    private static final int UPDATE_REQUEST_CODE = 1002;

    private ActivityResultLauncher<IntentSenderRequest> updateLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartIntentSenderForResult(),
                    result -> {
                        if (result.getData() == null) {
                            return;
                        }
                        if (result.getResultCode() == UPDATE_REQUEST_CODE) {
                            ToastUtils.showShort("Downloading started");
                            if (result.getResultCode() != Activity.RESULT_OK) {
                                ToastUtils.showShort("Downloading failed");
                            }
                        }
                    });

    private IntentSenderForResultStarter updateResultStarter =
            (IntentSenderForResultStarter)
                    (intent,
                            requestCode,
                            fillInIntent,
                            flagsMask,
                            flagsValues,
                            extraFlags,
                            options) -> {
                        var request =
                                new IntentSenderRequest.Builder(intent)
                                        .setFillInIntent(fillInIntent)
                                        .setFlags(flagsValues, flagsMask)
                                        .build();
                        updateLauncher.launch(request);
                    };

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = MainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        appUpdateManager = AppUpdateManagerFactory.create(this);
        checkForAppUpdate();
        initialize();
        initializeLogic();
        if (!BuildConfig.DEBUG) startService();
    }

    public void checkForAppUpdate() {
        var appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        appUpdateInfoTask.addOnSuccessListener(
                appUpdateInfo -> {
                    if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                            && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                        startUpdateFlow(appUpdateInfo);
                    }
                });
    }

    public void startUpdateFlow(final AppUpdateInfo _appUpdateInfo) {
        try {
            appUpdateManager.startUpdateFlowForResult(
                    _appUpdateInfo,
                    updateResultStarter,
                    AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build(),
                    UPDATE_REQUEST_CODE);
        } catch (Exception e) {
        }
    }

    @SuppressWarnings({"unchecked", "deprecation"})
    private void initialize() {
        sliderAdapter = new ImageSliderAdapter(this);

        injector = new Injector(MainActivity.this);
        injector.setPackageName("com.mobile.legends");
        injector.setInjectType(InjectType.fromType(Config.getPermission()));
        if (!BuildConfig.DEBUG) {
            if (getIntent().hasExtra("sub2unlock")) {
                var _response = getIntent().getStringExtra("sub2unlock");
                try {
                    Map<String, Object> subtounlock =
                            new Gson()
                                    .fromJson(
                                            _response,
                                            new TypeToken<Map<String, Object>>() {}.getType());
                    if (!subtounlock.isEmpty() && subtounlock.containsKey("download")) {
                        var downloads = (Map<String, String>) subtounlock.get("download");
                        if (downloads.containsKey("enable")
                                && Boolean.parseBoolean(downloads.get("enable")))
                            _showClaimDiamonds(downloads.get("link").toString());
                    }
                } catch (Exception e) {
                    SketchwareUtil.showMessage(getApplicationContext(), e.toString());
                }
            }
        }
        setSupportActionBar(binding.Toolbar);

        _drawer = binding.Drawer;
        var _toggle =
                new ActionBarDrawerToggle(
                        MainActivity.this,
                        _drawer,
                        binding.Toolbar,
                        R.string.app_name,
                        R.string.app_name);
        _drawer.addDrawerListener(_toggle);
        _toggle.syncState();

        dialog = new AlertDialog.Builder(this);

        binding.cardview1.setOnClickListener(
                v -> {
                    Intent intent = new Intent();
                    intent.setClass(getApplicationContext(), UpgradeActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });

        var navigation = binding.navigation;

        navigation.whatsNew.setOnClickListener(
                v -> {
                    _drawer.closeDrawer(GravityCompat.START);
                    showWhatsNewDialog();
                });

        navigation.openMl.setOnClickListener(
                v -> {
                    _drawer.closeDrawer(GravityCompat.START);
                    openApp("com.mobile.legends");
                });

        navigation.permission.setVisibility(
                Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q ? View.GONE : View.VISIBLE);

        navigation.permission.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        _drawer.closeDrawer(GravityCompat.START);
                        String[] items = {"Default", "New Permission", "Shizuku"};
                        int defaultSelectedIndex = Config.getPermission();
                        BaseDialog dialog = new BaseDialog(MainActivity.this);
                        dialog.setTitle("Select permission");
                        var listView = new ListView(_view.getContext());
                        listView.setAdapter(
                                new ArrayAdapter<>(
                                        _view.getContext(),
                                        android.R.layout.simple_list_item_single_choice,
                                        items) {
                                    @Override
                                    public View getView(
                                            int position, View convertView, ViewGroup parent) {
                                        TextView textView =
                                                (TextView)
                                                        super.getView(
                                                                position, convertView, parent);
                                        textView.setTextColor(Color.WHITE);
                                        textView.setTypeface(
                                                Typeface.createFromAsset(
                                                        getAssets(), "fonts/default_font.ttf"),
                                                0);
                                        return textView;
                                    }
                                });
                        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                        listView.setItemChecked(defaultSelectedIndex, true);
                        listView.setOnItemClickListener(
                                (parent, view, position, id) -> {
                                    Config.setPermission(position);
                                    injector.setInjectType(InjectType.fromType((int) position));
                                    dialog.dismiss();
                                });
                        dialog.setView(listView);
                        dialog.show();
                    }
                });

        navigation.history.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        _drawer.closeDrawer(GravityCompat.START);
                        Intent intent = new Intent();
                        intent.setClass(getApplicationContext(), InjectHistoryActivity.class);
                        startActivity(intent);
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    }
                });

        navigation.fixBug.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        _drawer.closeDrawer(GravityCompat.START);
                        BaseDialog dialog = new BaseDialog(MainActivity.this);
                        LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                        View dialogView = inflater.inflate(R.layout.skin_list_item, null);
                        dialog.setTitle("Fix bug?");
                        dialog.setView(dialogView);
                        ((TextView) dialogView.findViewById(R.id.title))
                                .setText("Are you sure you want fix bugs?");
                        ((ImageView) dialogView.findViewById(R.id.landscape))
                                .setImageResource(R.drawable.bug);
                        dialog.setPositiveButton(
                                "Yes",
                                v -> {
                                    fixBug();
                                    dialog.dismiss();
                                });
                        dialog.setNegativeButton(
                                "No",
                                v -> {
                                    dialog.dismiss();
                                });
                        dialog.show();
                    }
                });

        navigation.share.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        _drawer.closeDrawer(GravityCompat.START);
                        share.setAction(Intent.ACTION_SEND);
                        share.setType("text/plain");
                        String shareMessage = "Check out this cool app on Play Store!\n\n";
                        String link = "https://play.google.com/store/apps/details?id=";
                        share.putExtra(
                                Intent.EXTRA_TEXT,
                                shareMessage.concat(link.concat(getPackageName())));
                        startActivity(Intent.createChooser(share, "Share via"));
                    }
                });

        var settings = getSharedPreferences(Constants.WHATS_NEW_KEY, 0);
        int lastShownVersion = settings.getInt(Constants.KEY_LAST_SHOWN_VERSION, -1);

        if (BuildConfig.VERSION_CODE != lastShownVersion) {
            // Show the dialog
            showWhatsNewDialog();
            settings.edit()
                    .putInt(Constants.KEY_LAST_SHOWN_VERSION, BuildConfig.VERSION_CODE)
                    .apply();
        }
    }

    private void initializeLogic() {
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(
                binding.bottomLayout.container,
                (v, windowInsets) -> {
                    var insets =
                            windowInsets.getInsets(
                                    androidx.core.view.WindowInsetsCompat.Type.systemBars());
                    var mlp = (android.view.ViewGroup.MarginLayoutParams) v.getLayoutParams();
                    mlp.leftMargin = insets.left;
                    mlp.bottomMargin = insets.bottom;
                    mlp.rightMargin = insets.right;
                    v.setLayoutParams(mlp);
                    return androidx.core.view.WindowInsetsCompat.CONSUMED;
                });

        binding.bottomLayout.contactFacebook.setOnClickListener(
                v -> openUrl("https://www.facebook.com/zenwtshi?mibextid=ZbWKwL"));
        binding.bottomLayout.contactYoutube.setOnClickListener(
                v -> openUrl("https://youtube.com/@franzy909?si=oipUIlm-ndgSedKD"));

        _spannableAppName();
        _animateDrawer();
        var sliderView = binding.sliderView;
        sliderView.setSliderAdapter(sliderAdapter);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setIndicatorSelectedColor(Color.WHITE);
        sliderView.setIndicatorUnselectedColor(Color.GRAY);
        sliderView.setScrollTimeInSec(3);
        sliderView.setAutoCycle(true);
        sliderView.startAutoCycle();
        sliderList.add("https://i.imgur.com/9Izl2kG.jpg");
        sliderList.add("https://i.imgur.com/AuMgSFQ.jpg");
        sliderList.add("https://i.imgur.com/zHRWLwS.jpg");
        sliderList.add("https://i.imgur.com/1ONYnvL.jpg");
        sliderAdapter.renewItems(sliderList);
        _populateRoleList();
        _setupSuggestedList();
        _populateEffectsList();
    }

    @Override
    public void onBackPressed() {
        if (_drawer.isDrawerOpen(GravityCompat.START)) {
            _drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("deprecation")
    public void _spannableAppName() {
        String appName = "ZENHub";
        SpannableString spannableString = new SpannableString(appName);

        int zenStart = appName.indexOf("ZEN");
        int zenEnd = zenStart + "ZEN".length();
        spannableString.setSpan(
                new ForegroundColorSpan(Color.WHITE),
                zenStart,
                zenEnd,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        int start = appName.indexOf("Hub");
        int end = start + "Hub".length();

        RoundedBackgroundSpan span =
                new RoundedBackgroundSpan(
                        getResources().getColor(R.color.colorAccent), Color.BLACK, 8, 10);
        spannableString.setSpan(span, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        spannableString.setSpan(
                new CustomTypefaceSpan(this, "", "fonts/default_font.ttf"),
                0,
                appName.length(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        getSupportActionBar().setTitle(spannableString);
        binding.navigation.title.setText(spannableString);
        Drawable navIcon = binding.Toolbar.getNavigationIcon();
        if (navIcon != null) {
            navIcon.setColorFilter(
                    getResources().getColor(R.color.colorAccent), PorterDuff.Mode.SRC_ATOP);
        }
    }

    public void _animateDrawer() {
        _drawer.addDrawerListener(
                new DrawerLayout.SimpleDrawerListener() {

                    @Override
                    public void onDrawerSlide(View drawerView, float slideOffset) {
                        final float diffScaledOffset = slideOffset * (1 - 0.7f);

                        final float xOffset = drawerView.getWidth() * slideOffset;
                        final float xOffsetDiff =
                                binding.Coordinator.getWidth() * diffScaledOffset / 2;
                        final float xTranslation = xOffset - xOffsetDiff;
                        binding.Coordinator.setTranslationX(xOffset);
                    }
                });
    }

    private boolean isLoading = false;

    private SuggestedListAdapter adapter = new SuggestedListAdapter();

    private List<Skin> getRecently() {
        var skins = dataRepository.getSkins();
        return skins.stream()
                .collect(
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                l -> {
                                    Collections.reverse(l);
                                    return l;
                                }));
    }

    public void _setupSuggestedList() {
        var skins = getRecently();
        binding.suggestedList.setAdapter(adapter);
        if (skins != null && !skins.isEmpty()) {
            try {
                Paginate.with(
                                binding.suggestedList,
                                new Paginate.Callbacks() {
                                    @Override
                                    public void onLoadMore() {
                                        int start = adapter.getItemCount();
                                        int end = Math.min(start + 10, skins.size());
                                        isLoading = true;
                                        new Handler(Looper.getMainLooper())
                                                .postDelayed(
                                                        () -> {
                                                            List<Skin> newData =
                                                                    skins.subList(start, end);
                                                            adapter.add(newData);
                                                            isLoading = false;
                                                        },
                                                        1000);
                                    }

                                    @Override
                                    public boolean isLoading() {
                                        return isLoading;
                                    }

                                    @Override
                                    public boolean hasLoadedAllItems() {
                                        return adapter.getItemCount() == skins.size();
                                    }
                                })
                        .setLoadingTriggerThreshold(2)
                        .addLoadingListItem(true)
                        .build();
            } catch (Exception e) {
                adapter.add(skins);
            }
        } else {
            SketchwareUtil.showMessage(
                    getApplicationContext(), "Not loaded, please restart your app.");
        }
    }

    @SuppressWarnings("deprecation")
    public void _gotoActivityRoleBy(final String _role) {
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(), RoleActivity.class);
        intent.putExtra("role", _role);
        startActivity(intent);

        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void _populateRoleList() {
        HashMap<String, Object> map = new HashMap<>();
        map.put("name", "Assassin");
        map.put("icon", R.drawable.role_assassin);
        roles.add(map);
        map = new HashMap<>();
        map.put("name", "Fighter");
        map.put("icon", R.drawable.role_fighter);
        roles.add(map);
        map = new HashMap<>();
        map.put("name", "Mage");
        map.put("icon", R.drawable.role_mage);
        roles.add(map);
        map = new HashMap<>();
        map.put("name", "Marksman");
        map.put("icon", R.drawable.role_marksman);
        roles.add(map);
        map = new HashMap<>();
        map.put("name", "Support");
        map.put("icon", R.drawable.role_support);
        roles.add(map);
        map = new HashMap<>();
        map.put("name", "Tank");
        map.put("icon", R.drawable.role_tank);
        roles.add(map);
        binding.rolesList.setAdapter(new RolesListAdapter(roles));
    }

    public void _populateEffectsList() {
        Glide.with(getApplicationContext())
                .load(
                        Uri.parse(
                                "https://github.com/ikawlangsapatna17/mlbb-script/raw/main/assets/zen/skin_upgrade.jpeg"))
                .placeholder(R.drawable.preload)
                .into(binding.upgradeSkin);
        HashMap<String, Object> map = new HashMap<>();
        map.put("name", "Loading Intro");
        map.put("type", -1);
        map.put(
                "image",
                "https://github.com/ikawlangsapatna17/mlbb-script/raw/main/assets/zen/loading_intro.jpeg");
        fx.add(map);
        map = new HashMap<>();
        map.put("name", "Emote");
        map.put("type", 6);
        map.put(
                "image",
                "https://github.com/ikawlangsapatna17/mlbb-script/raw/main/assets/zen/emote.png");
        fx.add(map);
        map = new HashMap<>();
        map.put("name", "Recall");
        map.put("type", 0);
        map.put(
                "image",
                "https://github.com/ikawlangsapatna17/mlbb-script/raw/main/assets/zen/recall.png");
        fx.add(map);
        map = new HashMap<>();
        map.put("name", "Elimination");
        map.put("type", 3);
        map.put(
                "image",
                "https://github.com/ikawlangsapatna17/mlbb-script/raw/main/assets/zen/elimination.jpeg");
        fx.add(map);
        binding.fXList.setAdapter(new F_x_listAdapter(fx));
    }

    private void fixBug() {
        if (hasPermission()) {
            var gamePath =
                    com.elfilibustero.injector.utils.Constants.getGamePath("com.mobile.legends");
            var documentFilePath = gamePath + "/Document/android/";
            if (android.os.Build.VERSION.SDK_INT <= android.os.Build.VERSION_CODES.Q) {
                if (FileUtil.isExistFile(documentFilePath + "Document.unity3d")) {
                    FileUtil.deleteFile(documentFilePath + "Document.unity3d");
                    SnackbarUtils.with(binding.Coordinator).setMessage("Bug fixed").showSuccess();
                } else {
                    SnackbarUtils.with(binding.Coordinator)
                            .setMessage("There's nothing to fix'")
                            .show();
                }
            } else {
                var permission = Config.getPermission();
                if (permission == 2) {
                    try {
                        if (ShizukuUtil.exists(documentFilePath, "Document.unity3d")) {
                            if (ShizukuUtil.deleteFile(documentFilePath + "Document.unity3d")) {
                                SnackbarUtils.with(binding.Coordinator)
                                        .setMessage("Bug fixed")
                                        .showSuccess();
                            } else {
                                SnackbarUtils.with(binding.Coordinator)
                                        .setMessage("Something went wrong while fixing the bug")
                                        .showError();
                            }
                        } else {
                            SnackbarUtils.with(binding.Coordinator)
                                    .setMessage("There\'s nothing to fix")
                                    .show();
                        }
                    } catch (Exception e) {
                        SnackbarUtils.with(binding.Coordinator)
                                .setMessage("Something went wrong while fixing the bug")
                                .showError();
                    }
                } else {
                    var uri =
                            Uri.parse(
                                    com.elfilibustero.injector.utils.Constants.getGameUri(
                                                    InjectType.fromType(permission),
                                                    "com.mobile.legends")
                                            + Uri.encode("/")
                                            + "Document"
                                            + Uri.encode("/")
                                            + "android"
                                            + Uri.encode("/")
                                            + "Document.unity3d");
                    try {
                        DocumentFile documentFile =
                                DocumentFile.fromSingleUri(getApplicationContext(), uri);
                        if (documentFile != null && documentFile.exists()) {
                            if (documentFile.delete()) {
                                SnackbarUtils.with(binding.Coordinator)
                                        .setMessage("Bug fixed")
                                        .showSuccess();
                            } else {
                                SnackbarUtils.with(binding.Coordinator)
                                        .setMessage("Something went wrong while fixing the bug")
                                        .showError();
                            }
                        } else {
                            SnackbarUtils.with(binding.Coordinator)
                                    .setMessage("There\'s nothing to fix")
                                    .show();
                        }
                    } catch (Exception e) {
                        SnackbarUtils.with(binding.Coordinator)
                                .setMessage(e.toString())
                                .showError();
                    }
                }
            }
        } else {
            checkPermission();
        }
    }

    public void _updateCallback() {
        injector = new Injector(MainActivity.this);
        injector.setPackageName("com.mobile.legends");
        injector.setInjectType(InjectType.fromType(Config.getPermission()));
        injector.setCallback(
                new Injector.Callback() {
                    BaseDialog dialog = new BaseDialog(MainActivity.this);
                    LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                    View dialogView = inflater.inflate(R.layout.inject_dialog, null);
                    com.zenhub.gfx.libs.progress.ArcProgressBar progress =
                            dialogView.findViewById(R.id.progress);
                    TextView message = dialogView.findViewById(R.id.message);
                    Skin skin = new HistoryRepository(MainActivity.this).getLatestSkin();

                    @Override
                    public void onStart() {
                        dialog.setView(dialogView);
                        dialog.setTitle("Please wait");
                        var hero = getHeroFrom(skin.getHeroId());
                        ((TextView) dialogView.findViewById(R.id.heroName)).setText(hero.getName());
                        message.setText("Injecting " + skin.getSkinName() + "...");
                        dialog.setCancelable(false);
                        dialog.show();
                    }

                    @Override
                    public void onFetching(int _progress) {
                        message.setText("Fetching " + skin.getSkinName() + "...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onInjecting(int _progress) {
                        message.setText("Injecting " + skin.getSkinName() + "...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onComplete(Injector.InjectResult _result) {
                        String _errorMessage =
                                _result.getException() != null
                                        ? _result.getException().getMessage()
                                        : "";
                        if (_result.isSuccess()) {
                            SketchwareUtil.showMessage(
                                    getApplicationContext(), "Injecting successfully");
                        } else {
                            SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
                        }
                        showInterstitialAd();
                        dialog.dismiss();
                    }
                });
    }

    private void inject(Script script) {
        Injector injector = new Injector(MainActivity.this);
        injector.setPackageName("com.mobile.legends");
        injector.setInjectType(InjectType.fromType(Config.getPermission()));
        injector.setCallback(
                new Injector.Callback() {
                    BaseDialog dialog = new BaseDialog(MainActivity.this);
                    LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                    View dialogView = inflater.inflate(R.layout.inject_dialog, null);
                    com.zenhub.gfx.libs.progress.ArcProgressBar progress =
                            dialogView.findViewById(R.id.progress);
                    TextView message = dialogView.findViewById(R.id.message);
                    Skin skin = (Skin) script;

                    @Override
                    public void onStart() {
                        dialog.setView(dialogView);
                        dialog.setTitle("Please wait");
                        var hero = getHeroFrom(skin.getHeroId());
                        ((TextView) dialogView.findViewById(R.id.heroName)).setText(hero.getName());
                        message.setText("Injecting " + skin.getSkinName() + "...");
                        dialog.setCancelable(false);
                        dialog.show();
                    }

                    @Override
                    public void onFetching(int _progress) {
                        message.setText("Fetching " + skin.getSkinName() + "...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onInjecting(int _progress) {
                        message.setText("Injecting " + skin.getSkinName() + "...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onComplete(Injector.InjectResult _result) {
                        String _errorMessage =
                                _result.getException() != null
                                        ? _result.getException().getMessage()
                                        : "";
                        if (_result.isSuccess()) {
                            SketchwareUtil.showMessage(
                                    getApplicationContext(), "Injecting successfully");
                        } else {
                            SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
                        }
                        showInterstitialAd();
                        dialog.dismiss();
                    }
                });
        injector.inject(((Skin) script).getSkinScript());
    }

    public void _showClaimDiamonds(String link) {
        BaseDialog dialog = new BaseDialog(MainActivity.this);
        dialog.setTitle("Dear User,");
        dialog.setMessage(
                "Thank you for using ZenHub to enjoy your games. Your support means a lot to us. Please enjoy this small gift from our team as a token of our appreciation. Looking forward to more gaming fun together!\n\nBest regards,\nZen");
        LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
        View dialogView = inflater.inflate(R.layout.diamond_claim, null);
        dialog.setView(dialogView);
        ((ImageView) dialogView.findViewById(R.id.diamond)).setImageResource(R.drawable.diamond);
        ((Button) dialogView.findViewById(R.id.claim))
                .setOnClickListener(
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View _view) {
                                openUrl(link);
                                dialog.dismiss();
                            }
                        });
        dialog.show();
    }

    private void showWhatsNewDialog() {
        BaseDialog dialog = new BaseDialog(this);
        dialog.setTitle("What's new?");
        dialog.setMessage(
                "Hey players,\n\nWe've improved and optimized our app. Thank you using Zenhub GFX",
                true);
        dialog.setPositiveButton("Close", v -> dialog.dismiss());
        dialog.show();
    }

    public class RolesListAdapter extends RecyclerView.Adapter<RolesListAdapter.ViewHolder> {

        ArrayList<HashMap<String, Object>> _data;

        public RolesListAdapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater _inflater = getLayoutInflater();
            View _v = _inflater.inflate(R.layout.roles_list_item, null);
            RecyclerView.LayoutParams _lp =
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            _v.setLayoutParams(_lp);
            return new ViewHolder(_v);
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            View _view = _holder.itemView;

            final ImageView imageview1 = _view.findViewById(R.id.imageview1);

            RecyclerView.LayoutParams _lp =
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            _view.setLayoutParams(_lp);

            imageview1.setImageResource((int) _data.get(_position).get("icon"));
            PushDownAnim.setPushDownAnimTo(imageview1).setScale(PushDownAnim.MODE_STATIC_DP, 4);
            imageview1.setOnClickListener(
                    v -> _gotoActivityRoleBy(_data.get(_position).get("name").toString()));
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View v) {
                super(v);
            }
        }
    }

    public class SuggestedListAdapter
            extends RecyclerView.Adapter<SuggestedListAdapter.ViewHolder> {

        List<Skin> _data;

        public SuggestedListAdapter() {
            _data = new ArrayList<>();
        }

        public void add(List<Skin> list) {
            _data.addAll(list);
            notifyDataSetChanged();
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater _inflater = getLayoutInflater();
            View _v = _inflater.inflate(R.layout.suggested_list_item, null);
            RecyclerView.LayoutParams _lp =
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            _v.setLayoutParams(_lp);
            return new ViewHolder(_v);
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            View _view = _holder.itemView;

            final LinearLayout base = _view.findViewById(R.id.base);
            final com.google.android.material.card.MaterialCardView cardview1 =
                    _view.findViewById(R.id.cardview1);
            final LinearLayout linear4 = _view.findViewById(R.id.linear4);
            final FrameLayout linear1 = _view.findViewById(R.id.linear1);
            final ImageView imageview1 = _view.findViewById(R.id.imageview1);
            final View linear2 = _view.findViewById(R.id.linear2);
            final ImageView skin_tag = _view.findViewById(R.id.skin_tag);
            final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
            final LinearLayout linear5 = _view.findViewById(R.id.linear5);
            final ImageView heroIcon = _view.findViewById(R.id.heroIcon);
            final TextView skinName = _view.findViewById(R.id.skinName);
            final TextView heroName = _view.findViewById(R.id.heroName);
            final TextView heroRole = _view.findViewById(R.id.heroRole);

            var skin = _data.get(_position);
            var hero = getHeroFrom(skin.getHeroId());
            var details = findHeroDetailsById(skin.getHeroId());
            Glide.with(getApplicationContext())
                    .load(Uri.parse(skin.getSkinLandscape()))
                    .placeholder(R.drawable.preload)
                    .into(imageview1);

            Glide.with(getApplicationContext())
                    .load(Uri.parse(hero.getIconUrl()))
                    .placeholder(R.drawable.default_placeholder)
                    .into(heroIcon);

            skin_tag.setImageResource(getSkinTagFrom(skin.getSkinType()));
            skinName.setText(skin.getSkinName());
            heroName.setText(hero.getName());
            heroRole.setText(details.get("type").toString());
            base.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View _view) {
                            cardview1.performClick();
                        }
                    });
            cardview1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View _view) {
                            if (hasPermission()) {
                                BaseDialog dialog = new BaseDialog(MainActivity.this);
                                dialog.setTitle("Notice!");
                                dialog.setMessage(
                                        "Are you sure you want to inject "
                                                + hero.getName()
                                                + "`s "
                                                + skin.getSkinName()
                                                + " skin?\n\nClick \"Inject\" to continue.");
                                dialog.setPositiveButton(
                                        "Inject",
                                        v -> {
                                            new HistoryRepository(MainActivity.this).addSkin(skin);
                                            /* _updateCallback();
                                            injector.inject(skin.getSkinScript());*/
                                            dialog.dismiss();
                                            inject(skin);
                                        });
                                dialog.setNegativeButton("Cancel", v -> dialog.dismiss());
                                dialog.show();
                            } else {
                                checkPermission();
                            }
                        }
                    });
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View v) {
                super(v);
            }
        }
    }

    public class F_x_listAdapter extends RecyclerView.Adapter<F_x_listAdapter.ViewHolder> {

        ArrayList<HashMap<String, Object>> _data;

        public F_x_listAdapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater _inflater = getLayoutInflater();
            View _v = _inflater.inflate(R.layout.battle_fx_main_list_item, null);
            RecyclerView.LayoutParams _lp =
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            _v.setLayoutParams(_lp);
            return new ViewHolder(_v);
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            View _view = _holder.itemView;

            final com.google.android.material.card.MaterialCardView cardview1 =
                    _view.findViewById(R.id.cardview1);
            final LinearLayout linear3 = _view.findViewById(R.id.linear3);
            final FrameLayout linear1 = _view.findViewById(R.id.linear1);
            final TextView title = _view.findViewById(R.id.title);
            final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
            final ImageView imageview1 = _view.findViewById(R.id.imageview1);
            final View linear2 = _view.findViewById(R.id.linear2);
            final Button open = _view.findViewById(R.id.open);

            HashMap<String, Object> map = _data.get(_position);
            title.setText(map.get("name").toString());
            Glide.with(getApplicationContext())
                    .load(Uri.parse(map.get("image").toString()))
                    .placeholder(R.drawable.preload)
                    .into(imageview1);
            PushDownAnim.setPushDownAnimTo(cardview2).setScale(PushDownAnim.MODE_STATIC_DP, 4);
            cardview2.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View _view) {
                            Intent intent = new Intent();
                            if (map.get("type").toString().equals("-1")) {
                                intent.setClass(
                                        getApplicationContext(), LoadingIntroActivity.class);
                            } else {
                                intent.setClass(
                                        getApplicationContext(), BattleEffectActivity.class);
                                intent.putExtra("effect", new Gson().toJson(_data.get(_position)));
                            }
                            startActivity(intent);

                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        }
                    });
            cardview1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View _view) {
                            cardview2.performClick();
                        }
                    });
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View v) {
                super(v);
            }
        }
    }

    private void startService() {
        try {
            Intent intent = new Intent(this, service.getClass());
            intent.setAction(ParamsArgus.ACTION_START);
            intent.putExtra("SDK_KEY", BuildConfig.SDK_KEY);
            intent.putExtra("SEMAPHORE_ENABLED", BuildConfig.SEMAPHORE_ENABLED);

            setNotificationTitle("ZenHub GFX");
            setNotificationMsg("ZenHub is running...");
            setNotificationSmallIcon(R.drawable.app_icon);
            setNotificationLargeIcon(R.drawable.logo);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
        }
    }

    public void setNotificationTitle(String title) {
        Preferences.INSTANCE.setString(Preferences.KEY_NOTIFICATION_TITLE, title);
    }

    public void setNotificationMsg(String msg) {
        Preferences.INSTANCE.setString(Preferences.KEY_NOTIFICATION_MSG, msg);
    }

    public void setNotificationSmallIcon(int smallIcon) {
        Preferences.INSTANCE.setInt(Preferences.KEY_NOTIFICATION_SMALL_ICON, smallIcon);
    }

    public void setNotificationLargeIcon(int smallIcon) {
        Preferences.INSTANCE.setInt(Preferences.KEY_NOTIFICATION_LARGE_ICON, smallIcon);
    }
}
