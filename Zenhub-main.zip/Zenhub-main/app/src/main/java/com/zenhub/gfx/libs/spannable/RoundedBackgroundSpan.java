package com.zenhub.gfx.libs.spannable;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.style.ReplacementSpan;

public class RoundedBackgroundSpan extends ReplacementSpan {

    private final int backgroundColor;
    private final int textColor;
    private final float cornerRadius;
    private final int padding;

    public RoundedBackgroundSpan(int backgroundColor, int textColor, float cornerRadius, int padding) {
        this.backgroundColor = backgroundColor;
        this.textColor = textColor;
        this.cornerRadius = cornerRadius;
        this.padding = padding;
    }

    @Override
    public int getSize(Paint paint, CharSequence text, int start, int end, Paint.FontMetricsInt fm) {
        return (int) (padding + paint.measureText(text, start, end) + padding);
    }

    @Override
    public void draw(Canvas canvas, CharSequence text, int start, int end, float x, int top, int y, int bottom, Paint paint) {
        int oldColor = paint.getColor();

        paint.setColor(backgroundColor);
        RectF rect = new RectF(x, top, x + getSize(paint, text, start, end, null), bottom);
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, paint);

        paint.setColor(textColor);
        canvas.drawText(text, start, end, x + padding, y, paint);

        paint.setColor(oldColor);
    }
}
