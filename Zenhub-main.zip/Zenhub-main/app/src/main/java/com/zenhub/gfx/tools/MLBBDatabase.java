package com.zenhub.gfx.tools;

import com.elfilibustero.mlbbdbc.enums.ItemType;
import com.elfilibustero.mlbbdbc.models.BattleEffect;
import com.elfilibustero.mlbbdbc.models.HeroResponse.Hero;
import com.elfilibustero.mlbbdbc.models.Skin;
import com.elfilibustero.mlbbdbc.models.UpgradeSkin;
import com.elfilibustero.mlbbdbc.tools.BattleEffectDecipher;
import com.elfilibustero.mlbbdbc.tools.SkinDecipher;
import com.elfilibustero.mlbbdbc.tools.UpgradeDataDecipher;
import com.elfilibustero.mlbbdbc.tools.UpgradeSkinDecipher;
import com.elfilibustero.mlbbdbc.utils.ConvertUtil;
import com.elfilibustero.mlbbdbc.utils.MLBytesDecryptor;
import com.elfilibustero.mlbbdbc.utils.MLBytesEncryptor;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zenhub.gfx.AppLoader;
import com.zenhub.gfx.R;
import com.zenhub.gfx.utils.Constants;
import com.zenhub.gfx.utils.FileUtil;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MLBBDatabase {

    public static List<String> getTypeNames() {
        return ItemType.getNames();
    }

    public static String getDataFrom(ItemType type) {
        return AppLoader.getContext().getExternalFilesDir("MLUpdate").getAbsolutePath()
                + "/"
                + getFileName(type.getName());
    }

    public static String getFileName(String typeName) {
        return MLBytesEncryptor.toInt(typeName) + ".mlbytes";
    }

    public static List<String> getUrls() {
        List<String> urls = new ArrayList<>();
        for (String name : getTypeNames()) {
            urls.add(Constants.DATABASE_ENDPOINT + getFileName(name));
        }
        return urls;
    }

    public static List<BattleEffect> readEffects() throws Exception {
        var filePath = getDataFrom(ItemType.BATTLE_EFFECT);
        if (!FileUtil.isExistFile(filePath)) {
            return new ArrayList<>();
        }
        var data = MLBytesDecryptor.decrypt(filePath);
        return new BattleEffectDecipher().parse(data);
    }

    public static List<Skin> readSkins() throws Exception {
        var filePath = getDataFrom(ItemType.SKIN);
        if (!FileUtil.isExistFile(filePath)) {
            return new ArrayList<>();
        }
        var data = MLBytesDecryptor.decrypt(filePath);
        return new SkinDecipher().parse(data);
    }

    public static List<UpgradeSkin> readUpgradeSkins() throws Exception {
        var filePath = getDataFrom(ItemType.UPGRADE);
        if (!FileUtil.isExistFile(filePath)) {
            return new ArrayList<>();
        }
        var data = MLBytesDecryptor.decrypt(filePath);
        return new UpgradeSkinDecipher().parse(data);
    }

    public static List<UpgradeSkin.Data> readUpgradeSkinsData() throws Exception {
        var filePath = getDataFrom(ItemType.UPGRADE_DATA);
        if (!FileUtil.isExistFile(filePath)) {
            return new ArrayList<>();
        }
        var data = MLBytesDecryptor.decrypt(filePath);
        return new UpgradeDataDecipher().parse(data);
    }

    public static Map<String, Object> readHeroDetails() throws Exception {
        var filePath = getDataFrom(ItemType.HERO);
        if (!FileUtil.isExistFile(filePath)) {
            return new HashMap<>();
        }
        var data = MLBytesDecryptor.decrypt(filePath);
        return new Gson()
                .fromJson(
                        ConvertUtil.bytesToString(data),
                        new TypeToken<Map<String, Object>>() {}.getType());
    }

    public static void parse(String filePath) {
        DataRepository repository = DataRepository.getInstance();
        if (filePath == null || filePath.isEmpty()) {
            return;
        }
        System.out.println("File path: " + filePath);
        String fileName = FileUtil.getFileName(filePath);
        System.out.println("File name: " + fileName);
        try {
            var data = MLBytesDecryptor.decrypt(filePath);
            if (fileName.equalsIgnoreCase(getFileName(ItemType.BATTLE_EFFECT.getName()))) {
                repository.setEffects(new BattleEffectDecipher().parse(data));
            } else if (fileName.equalsIgnoreCase(getFileName(ItemType.SKIN.getName()))) {
                repository.setSkins(new SkinDecipher().parse(data));
            } else if (fileName.equalsIgnoreCase(getFileName(ItemType.UPGRADE.getName()))) {
                repository.setUpgradeSkins(new UpgradeSkinDecipher().parse(data));
            } else if (fileName.equalsIgnoreCase(getFileName(ItemType.UPGRADE_DATA.getName()))) {
                repository.setUpgradeSkinsData(new UpgradeDataDecipher().parse(data));
            } else if (fileName.equalsIgnoreCase(getFileName(ItemType.HERO.getName()))) {
                repository.setHeroDetails(
                        new Gson()
                                .fromJson(
                                        ConvertUtil.bytesToString(data),
                                        new TypeToken<Map<String, Object>>() {}.getType()));
            }
        } catch (Exception ignored) {
            System.out.println(ignored);
        }
    }

    public static ArrayList<HashMap<String, Object>> filterSkin(
            String input, ArrayList<HashMap<String, Object>> skins) {
        ArrayList<HashMap<String, Object>> filtered = new ArrayList<>();

        if (input == null || input.isEmpty()) {
            return skins;
        }

        String lowerCaseInput = input.toLowerCase();

        for (HashMap<String, Object> map : skins) {
            Hero hero = (Hero) map.get("hero");
            if (hero != null && hero.getName() != null) {
                String heroNameLowerCase = hero.getName().toLowerCase();
                if (heroNameLowerCase.contains(lowerCaseInput)) {
                    filtered.add(map);
                }
            }
        }

        return filtered;
    }

    public static List<BattleEffect> filterEffects(String input, List<BattleEffect> effects) {
        List<BattleEffect> filtered = new ArrayList<>();

        if (input == null || input.isEmpty()) {
            return effects;
        }

        String lowerCaseInput = input.toLowerCase();

        for (BattleEffect effect : effects) {
            String name = effect.getName().toLowerCase();
            if (name.contains(lowerCaseInput)) {
                filtered.add(effect);
            }
        }

        return filtered;
    }

    public static int getRoleIconByType(String role) {
        return switch (role) {
            case "Assassin" -> R.drawable.role1;
            case "Fighter" -> R.drawable.role2;
            case "Mage" -> R.drawable.role3;
            case "Marksman" -> R.drawable.role4;
            case "Support" -> R.drawable.role5;
            case "Tank" -> R.drawable.role6;
            default -> R.drawable.role1;
        };
    }

    public static List<Skin> getSkinsOf(final int _id) {
        List<Skin> skins = new ArrayList<>();
        var temp = DataRepository.getInstance().getSkins();
        if (temp == null || temp.isEmpty()) {
            return new ArrayList<>();
        }
        for (Skin skin : temp) {
            if (skin.getHeroId() == _id) {
                skins.add(skin);
            }
        }
        if (!skins.isEmpty()) {
            skins.sort((s1, s2) -> Integer.compare(s1.getSkinId(), s2.getSkinId()));
        }
        return skins;
    }

    public static List<Skin> findSkinsByCategory(int id, int category) {
        return getSkinsOf(id).stream()
                .filter(skin -> skin.getSkinCategory() == category)
                .collect(Collectors.toList());
    }
    
    @SuppressWarnings("unchecked")
    public static Map<String, Object> findHeroDetailsById(int id) {
        var details = DataRepository.getInstance().getHeroDetails();
        if (details.containsKey(String.valueOf(id))) {
            return (Map<String, Object>) details.get(String.valueOf(id));
        }
        return new HashMap<>();
    }

    public static ArrayList<HashMap<String, Object>> getSkinsByCategory(String role, int category) {
        ArrayList<HashMap<String, Object>> skinList = new ArrayList<>();
        var heroes = DataRepository.getInstance().getHeroes();
        if (heroes == null || heroes.isEmpty()) {
            return new ArrayList<>();
        }
        heroes.sort(Comparator.comparing(Hero::getName));
        heroes.forEach(
                hero -> {
                    var detail = findHeroDetailsById(hero.getId());
                    if (detail.containsKey("type")) {
                        if (detail.get("type").toString().equalsIgnoreCase(role)) {
                            List<Skin> heroSkins = new ArrayList<>();
                            if (category != 0) {
                                List<Skin> skins = getSkinsOf(hero.getId());
                                for (Skin skin : skins) {
                                    if (skin.getSkinType().equalsIgnoreCase("Backup")) {
                                        heroSkins.add(skin);
                                        break;
                                    }
                                }
                            }
                            heroSkins.addAll(findSkinsByCategory(hero.getId(), category));
                            if (heroSkins != null && !heroSkins.isEmpty() && heroSkins.size() > 1) {
                                HashMap<String, Object> map = new HashMap<>();
                                map.put("hero", hero);
                                map.put("skins", heroSkins);
                                skinList.add(map);
                            }
                        }
                    }
                });
        return skinList;
    }
}
