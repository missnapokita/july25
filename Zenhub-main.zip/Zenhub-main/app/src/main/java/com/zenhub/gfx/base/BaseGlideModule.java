package com.zenhub.gfx.base;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class BaseGlideModule extends AppGlideModule {
    // Leave this class empty for Glide annotations
}
