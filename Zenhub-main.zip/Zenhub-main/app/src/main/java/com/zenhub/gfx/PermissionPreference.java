package com.zenhub.gfx;

import android.app.Activity;
import android.content.SharedPreferences;

import static com.zenhub.gfx.AppLoader.getContext;

public class PermissionPreference {
	
	private static final String PERMISSION_PREFERENCE_FILE = "permission_preference";
    private static final String PERMISSION_REQUEST = "permission";
	
	private static SharedPreferences prefs = getContext().getSharedPreferences(PERMISSION_PREFERENCE_FILE, Activity.MODE_PRIVATE);
    
    public static void setPermissionDeniedOnce(boolean a){
        prefs.edit().putBoolean(PERMISSION_REQUEST, a).commit();
    }
    
    public static boolean isPermissionDeniedOnce(){
        return  prefs.getBoolean(PERMISSION_REQUEST, false);
    }
    
}
