package com.zenhub.gfx.activities;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.elfilibustero.injector.downloader.FileDownloader;
import com.zenhub.gfx.R;
import com.zenhub.gfx.utils.FileUtil;
import com.zenhub.gfx.utils.SketchwareUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VideoPlayerActivity extends AppCompatActivity
        implements FileDownloader.DownloadCallback {

    private String url = "";
    private FileDownloader downloader;

    private List<String> urls = new ArrayList<>();

    private RelativeLayout linear1;
    private VideoView videoView;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.video_player);
        initialize();
    }

    private void initialize() {
        linear1 = findViewById(R.id.linear1);
        videoView = findViewById(R.id.videoView);
        MediaController videoView_controller = new MediaController(this);
        videoView.setMediaController(videoView_controller);
        progress = findViewById(R.id.progress);
        url = getIntent().getStringExtra("url");
        MediaController mediaController = new MediaController(this);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);

        videoView.setOnPreparedListener(
                mp -> {
                    videoView.start();
                    progress.setVisibility(View.GONE);
                });

        downloader = new FileDownloader(this);
        downloader.setDirectory("assets");

        urls.add(url);
        downloader.downloadUrls(urls, this);
    }

    @Override
    public void onComplete(List<String> downloadedFiles) {
        String filePath = downloadedFiles.get(0);
        String path = new File(filePath).getParent();
        if (FileUtil.Unzip(filePath, path)) {
            FileUtil.deleteFile(filePath);
            if (FileUtil.isExistFile(path.concat("/Audio/android/splash.mp4"))) {
                videoView.setVideoURI(Uri.parse(path.concat("/Audio/android/splash.mp4")));
                return;
            } else {
                SketchwareUtil.showMessage(getApplicationContext(), "Unable to play the video");
                finish();
            }
            return;
        }
    }

    @Override
    public void onError(String errorMessage) {
        SketchwareUtil.showMessage(getApplicationContext(), errorMessage);
        finish();
    }

    @Override
    public void onProgress(int progress) {
    }
}
