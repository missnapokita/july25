package com.zenhub.gfx.tools;

import android.content.Context;
import android.content.SharedPreferences;

import com.elfilibustero.mlbbdbc.models.BattleEffect;
import com.elfilibustero.mlbbdbc.models.Skin;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class HistoryRepository {
	
	private static final String PREFS_NAME = "History";
	private static final String SKINS_KEY = "skin";
    private static final String EFFECTS_KEY = "effect";
	private static final int MAX_HISTORY_ITEMS = 10;
	
	private SharedPreferences sharedPreferences;
	private Gson gson;
	
	public HistoryRepository(Context context) {
		sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
		gson = new Gson();
	}
    
    public List<Skin> loadSkins() {
        String json = sharedPreferences.getString(SKINS_KEY, null);
        Type type = new TypeToken<List<Skin>>() {}.getType();
        List<Skin> historyList = gson.fromJson(json, type);
        if (historyList == null) {
            return new ArrayList<>();
        }
        return historyList;
    }
    
    public Skin getLatestSkin() {
        var historyList = loadSkins();
        if (historyList == null || historyList.isEmpty()) {
			return null;
		}
        return historyList.get(0);
    }
	
	public void saveSkins(List<Skin> historyList) {
        if (historyList.size() > MAX_HISTORY_ITEMS) {
            historyList = historyList.subList(historyList.size() - MAX_HISTORY_ITEMS, historyList.size());
        }
        
		String json = gson.toJson(historyList);
		sharedPreferences.edit().putString(SKINS_KEY, json).apply();
	}
	
	public void addSkin(Skin skin) {
		List<Skin> historyList = loadSkins();
		
		if (historyList == null) {
			historyList = new ArrayList<>();
		}
		
		var existingItem = historyList.stream()
                .filter(_skin -> _skin.equals(skin))
                .findFirst();

        if (existingItem.isPresent()) {
            historyList.remove(existingItem.get());
        }

        historyList.add(0, skin);

        saveSkins(historyList);
	}
	
	public List<BattleEffect> loadEffects() {
		String json = sharedPreferences.getString(EFFECTS_KEY, null);
        Type type = new TypeToken<List<BattleEffect>>() {}.getType();
        List<BattleEffect> historyList = gson.fromJson(json, type);
        if (historyList == null) {
            return new ArrayList<>();
        }
        return historyList;
	}
    
    public BattleEffect getLatestEffect() {
        var historyList = loadEffects();
        if (historyList == null || historyList.isEmpty()) {
			return null;
		}
        return historyList.get(0);
    }
	
	public void saveEffects(List<BattleEffect> historyList) {
        if (historyList.size() > MAX_HISTORY_ITEMS) {
            historyList = historyList.subList(historyList.size() - MAX_HISTORY_ITEMS, historyList.size());
        }
        
		String json = gson.toJson(historyList);
		sharedPreferences.edit().putString(EFFECTS_KEY, json).apply();
	}
	
	public void addEffect(BattleEffect effect) {
		List<BattleEffect> historyList = loadEffects();
		
		if (historyList == null) {
			historyList = new ArrayList<>();
		}
		
		var existingItem = historyList.stream()
                .filter(_effect -> _effect.equals(effect))
                .findFirst();

        if (existingItem.isPresent()) {
            historyList.remove(existingItem.get());
        }

        historyList.add(0, effect);

        saveEffects(historyList);
	}
}
