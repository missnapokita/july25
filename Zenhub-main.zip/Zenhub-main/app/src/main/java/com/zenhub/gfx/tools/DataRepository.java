package com.zenhub.gfx.tools;

import com.elfilibustero.mlbbdbc.models.BattleEffect;
import com.elfilibustero.mlbbdbc.models.HeroResponse;
import com.elfilibustero.mlbbdbc.models.Skin;
import com.elfilibustero.mlbbdbc.models.UpgradeSkin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zenhub.gfx.AppLoader;
import com.zenhub.gfx.utils.FileUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataRepository {
    private static DataRepository instance;
    private List<BattleEffect> effects;
    private List<Skin> skins;
    private List<UpgradeSkin> upgradeSkins;
    private List<UpgradeSkin.Data> upgradeSkinsData;
    private List<HeroResponse.Hero> heroes;

    private Map<String, Object> heroDetails;

    private DataRepository() {}

    public static synchronized DataRepository getInstance() {
        if (instance == null) {
            instance = new DataRepository();
        }
        return instance;
    }

    public List<HeroResponse.Hero> getHeroes() {
        try {
            if (heroes == null || heroes.isEmpty()) {
                var data = FileUtil.readLocalFile(AppLoader.getContext(), "hero_list.json");
                if (data != null) {
                    heroes =
                            new Gson()
                                    .fromJson(
                                            data,
                                            new TypeToken<List<HeroResponse.Hero>>() {}.getType());
                } else {
                    heroes = new ArrayList<>();
                }
            }
        } catch (Exception e) {
            heroDetails = new HashMap<>();
        }
        return heroes;
    }

    public void setHeroes(List<HeroResponse.Hero> heroes) {
        this.heroes = heroes;
    }

    public Map<String, Object> getHeroDetails() {
        try {
            if (heroDetails == null || heroDetails.isEmpty())
                heroDetails = MLBBDatabase.readHeroDetails();
        } catch (Exception e) {
            heroDetails = new HashMap<>();
        }
        return heroDetails;
    }

    public void setHeroDetails(Map<String, Object> details) {
        this.heroDetails = details;
    }

    public List<BattleEffect> getEffects() {
        try {
            if (effects == null || effects.isEmpty()) effects = MLBBDatabase.readEffects();
        } catch (Exception e) {
            effects = new ArrayList<>();
        }
        return effects;
    }

    public void setEffects(List<BattleEffect> effects) {
        this.effects = effects;
    }

    public List<Skin> getSkins() {
        try {
            if (skins == null || skins.isEmpty()) skins = MLBBDatabase.readSkins();
        } catch (Exception e) {
            skins = new ArrayList<>();
        }
        return skins;
    }

    public void setSkins(List<Skin> skins) {
        this.skins = skins;
    }

    public List<UpgradeSkin> getUpgradeSkins() {
        try {
            if (upgradeSkins == null || upgradeSkins.isEmpty())
                upgradeSkins = MLBBDatabase.readUpgradeSkins();
        } catch (Exception e) {
            upgradeSkins = new ArrayList<>();
        }
        return upgradeSkins;
    }

    public void setUpgradeSkins(List<UpgradeSkin> upgradeSkins) {
        this.upgradeSkins = upgradeSkins;
    }

    public List<UpgradeSkin.Data> getUpgradeSkinsData() {
        try {
            if (upgradeSkinsData == null || upgradeSkinsData.isEmpty())
                upgradeSkinsData = MLBBDatabase.readUpgradeSkinsData();
        } catch (Exception e) {
            upgradeSkinsData = new ArrayList<>();
        }
        return upgradeSkinsData;
    }

    public void setUpgradeSkinsData(List<UpgradeSkin.Data> upgradeSkinsData) {
        this.upgradeSkinsData = upgradeSkinsData;
    }
}
