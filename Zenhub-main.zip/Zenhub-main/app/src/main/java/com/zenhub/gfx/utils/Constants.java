package com.zenhub.gfx.utils;

public class Constants {

    public static final String WHATS_NEW_KEY = "whats_new";
    public static final String KEY_LAST_SHOWN_VERSION = "last_version_code";
    public static final String AD_NAME_APP_OPEN = "App Open";
    public static final String AD_NAME_ROLE_ACTIVITY = "RoleActivity";

    public static final String DATABASE_ENDPOINT =
            "https://github.com/ikawlangsapatna17/mlbb-script/raw/main/database/";

    public static final String[] ROLES = {
        "Assassin", "Fighter", "Mage", "Marksman", "Support", "Tank"
    };
}
