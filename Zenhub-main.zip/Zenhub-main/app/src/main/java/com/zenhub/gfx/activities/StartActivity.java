package com.zenhub.gfx.activities;

import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.blankj.utilcode.util.ToastUtils;
import com.elfilibustero.injector.downloader.FileDownloader;
import com.elfilibustero.mlbbdbc.models.HeroResponse;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zenhub.gfx.AppLoader;
import com.zenhub.gfx.BuildConfig;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.databinding.StartBinding;
import com.zenhub.gfx.dialogs.UnskippableDialog;
import com.zenhub.gfx.libs.network.RequestNetwork;
import com.zenhub.gfx.libs.network.RequestNetworkController;
import com.zenhub.gfx.tools.DataRepository;
import com.zenhub.gfx.tools.MLBBDatabase;
import com.zenhub.gfx.tools.PreferenceFactory;
import com.zenhub.gfx.utils.FileUtil;
import com.zenhub.gfx.utils.SketchwareUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class StartActivity extends BaseActivity
        implements FileDownloader.DownloadCallback, RequestNetwork.RequestListener {

    private StartBinding binding;
    private FileDownloader downloader;
    private HashMap<String, Object> map = new HashMap<>();

    private Intent intent = new Intent();
    private RequestNetwork request;

    private ConsentInformation consentInformation;

    private Map<String, Object> subtounlock;

    private DataRepository repository;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = StartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        repository = DataRepository.getInstance();
        initializeLogic();
    }

    private void initializeLogic() {
        downloader = new FileDownloader(this);
        downloader.setDirectory("MLUpdate");
        request = new RequestNetwork(this);
        request.startRequestNetwork(
                RequestNetworkController.GET,
                "https://github.com/ikawlangsapatna17/mlbb-script/raw/main/assets/zen/data/new_subtounlock.json",
                "sub2unlock",
                this);
        ViewCompat.setOnApplyWindowInsetsListener(
                binding.progress,
                (v, windowInsets) -> {
                    var insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
                    var mlp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                    mlp.leftMargin += insets.left;
                    mlp.bottomMargin = insets.bottom;
                    mlp.rightMargin += insets.right;
                    v.setLayoutParams(mlp);
                    return WindowInsetsCompat.CONSUMED;
                });
    }

    @Override
    public void onComplete(List<String> downloadedFiles) {
        for (String path : downloadedFiles) {
            MLBBDatabase.parse(path);
        }
        loadDashboard(true);
    }

    @Override
    public void onError(String errorMessage) {
        SketchwareUtil.showMessage(getApplicationContext(), errorMessage);
    }

    @Override
    public void onProgress(int progress) {}

    @Override
    public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
        final String _tag = _param1;
        final String _response = _param2;
        final HashMap<String, Object> _responseHeaders = _param3;
        if (_tag.equals("hero_list")) {
            var result = HeroResponse.fromJson(_response);
            if (result.code == 2000) {
                FileUtil.writeLocalFile(this, "hero_list.json", new Gson().toJson(result.data));
            }
            downloader.downloadUrls(MLBBDatabase.getUrls(), this);
        } else if (_tag.equals("sub2unlock")) {
            try {
                subtounlock =
                        new Gson()
                                .fromJson(
                                        _response,
                                        new TypeToken<Map<String, Object>>() {}.getType());
                if (subtounlock != null && subtounlock.containsKey("show")) {
                    var showDialog = subtounlock.get("show").toString();
                    if (showDialog != null
                            && !showDialog.isEmpty()
                            && showDialog.equalsIgnoreCase("hide")) {
                        fetchResources();
                        return;
                    }
                }
                if (BuildConfig.DEBUG) {
                    fetchResources();
                } else {
                    UnskippableDialog fragment = UnskippableDialog.newInstance(_response);
                    fragment.setOnDismissListener(() -> fetchResources());
                    fragment.show(getSupportFragmentManager(), "unskippable");
                }
            } catch (Exception e) {
                fetchResources();
            }
        }
    }

    @Override
    public void onErrorResponse(String _param1, String _param2) {
        final String _tag = _param1;
        final String _message = _param2;
        // SketchwareUtil.showMessage(getApplicationContext(), _message);
        SketchwareUtil.showMessage(
                getApplicationContext(), "Poor internet connection exiting in 3 seconds");
        new Handler(Looper.getMainLooper()).postDelayed(() -> finish(), 3000);
    }

    private static final String LAST_FETCH_DATE_KEY = "lastFetchDate";
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private void fetchResources() {
        try {
            String lastFetchDate =
                    PreferenceFactory.getInstance().readString(LAST_FETCH_DATE_KEY, null);
            String currentDate =
                    new SimpleDateFormat(DATE_FORMAT, Locale.getDefault())
                            .format(Calendar.getInstance().getTime());
            if (!currentDate.equals(lastFetchDate)
                    || !FileUtil.existsLocalFile(this, "hero_list.json")) {
                PreferenceFactory.getInstance().writeString(LAST_FETCH_DATE_KEY, currentDate);
                request.startRequestNetwork(
                        RequestNetworkController.GET,
                        HeroResponse.HERO_LIST_ENDPOINT,
                        "hero_list",
                        this);
                binding.textview1.setText("Fetching resources...");
            } else {
                if (!FileUtil.isExistFile(
                        AppLoader.getContext().getExternalFilesDir("MLUpdate").getAbsolutePath())) {
                    downloader.downloadUrls(MLBBDatabase.getUrls(), this);
                } else {
                    loadDashboard(true);
                }
            }
        } catch (Exception e) {
            ToastUtils.showShort(
                    "Something went wrong, please try again later.\n\nError: "
                            + e.getLocalizedMessage());
        }
    }

    private void loadDashboard(boolean load) {
        if (load) {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
                if (!_permissionsGranted()) {
                    intent.setClass(getApplicationContext(), PermissionActivity.class);
                    startActivity(intent);
                    finish();
                    return;
                }
            }
            intent.setClass(getApplicationContext(), MainActivity.class);
            intent.putExtra("sub2unlock", new Gson().toJson(subtounlock));
            startActivity(intent);
            finish();
        } else {
            loadForm();
        }
    }

    public void consent() {
        ConsentRequestParameters params =
                new ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build();

        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> {
                    if (consentInformation.isConsentFormAvailable()) {
                        loadForm();
                    } else {
                        loadDashboard(false);
                    }
                },
                formError -> {
                    // Handle the error.
                    // AndroidUtil.showMessage(getApplicationContext(), formError.getMessage());
                    SketchwareUtil.showMessage(getApplicationContext(), formError.getMessage());
                    loadDashboard(false);
                });
    }

    public void loadForm() {
        // Loads a consent form. Must be called on the com.phgamingmods.mlscripts.models.main
        // thread.
        UserMessagingPlatform.loadConsentForm(
                this,
                consentForm -> {
                    // The consent form was loaded successfully.
                    if (consentInformation.getConsentStatus()
                            == ConsentInformation.ConsentStatus.REQUIRED) {
                        // Show the consent form to the user if consent is required.
                        consentForm.show(
                                this,
                                formError -> {
                                    // The consent form was dismissed by the user.
                                    if (consentInformation.getConsentStatus()
                                            == ConsentInformation.ConsentStatus.OBTAINED) {
                                        // If consent was obtained after showing the form, load the
                                        // dashboard.
                                        loadDashboard(true);
                                    } else {
                                        // If consent was not obtained, try loading the form again.
                                        loadForm();
                                    }
                                });
                    } else {
                        if (consentInformation.getConsentStatus()
                                == ConsentInformation.ConsentStatus.OBTAINED) {
                            // If consent was obtained after showing the form, load the dashboard.
                            loadDashboard(true);
                        } else {
                            // If consent was not obtained, try loading the form again.
                            loadForm();
                        }
                    }
                },
                formError -> {
                    // Handle the error that occurred while loading the consent form.
                    SketchwareUtil.showMessage(getApplicationContext(), formError.getMessage());
                    loadDashboard(false);
                });
    }
}
