package com.zenhub.gfx.activities;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.thekhaeng.pushdownanim.PushDownAnim;
import com.zenhub.gfx.PermissionPreference;
import com.zenhub.gfx.R;
import com.zenhub.gfx.databinding.PermissionBinding;

public class PermissionActivity extends AppCompatActivity {

    private PermissionBinding binding;

    private Snackbar denied;
    private ActivityResultLauncher<String[]> mPermissionLauncher;
    
    private final ActivityResultContracts.RequestMultiplePermissions mPermissionsContract =
            new ActivityResultContracts.RequestMultiplePermissions();

    private Intent intent = new Intent();
    private SharedPreferences permission;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = PermissionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();
    }

    private void initialize() {
        PushDownAnim.setPushDownAnimTo(binding.grant).setScale(PushDownAnim.MODE_STATIC_DP, 4);
        mPermissionLauncher =
                registerForActivityResult(
                        mPermissionsContract,
                        isGranted -> {
                            if (isGranted.containsValue(false)) {
                                if (_shouldShowRequestPermissionRationale()) {
                                    PermissionPreference.setPermissionDeniedOnce(true);
                                }
                                _showDeniedSnackbar();
                            } else {
                                intent.setClass(getApplicationContext(), MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        });

        permission = getSharedPreferences("storage_permission", Activity.MODE_PRIVATE);

        binding.grant.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        if (_permissionsGranted()) {
                            intent.setClass(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            _checkPermission();
                        }
                    }
                });
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void _showDeniedSnackbar() {
        if (denied == null || !denied.isShown()) {
            denied =
                    Snackbar.make(
                            findViewById(R.id._coordinator),
                            "Permission denied",
                            Snackbar.LENGTH_INDEFINITE);
            denied.setAction(
                    "Settings",
                    v -> {
                        denied.dismiss();
                        _showAppSettings();
                    });
            denied.setActionTextColor(Color.YELLOW);
            denied.show();
        }
    }

    public boolean _shouldShowRequestPermissionRationale() {
        return (shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)
                || shouldShowRequestPermissionRationale(
                        Manifest.permission.WRITE_EXTERNAL_STORAGE));
    }

    public void _requestPermissions() {
        mPermissionLauncher.launch(
                new String[] {
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                });
    }

    public void _checkPermission() {
        if (!_permissionsGranted()) {
            if (_shouldShowRequestPermissionRationale()) {
                if (PermissionPreference.isPermissionDeniedOnce()) {
                    _requestPermissions();
                } else {
                    _showDeniedSnackbar();
                }
            } else {
                _requestPermissions();
            }
        }
    }

    public boolean _permissionsGranted() {
        return (ContextCompat.checkSelfPermission(
                                this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(
                                this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED);
    }

    public void _showAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }
}
