package com.zenhub.gfx.utils;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.TextUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class FileUtil {
	
	private static void createNewFile(String path) {
		int lastSep = path.lastIndexOf(File.separator);
		if (lastSep > 0) {
			String dirPath = path.substring(0, lastSep);
			makeDir(dirPath);
		}
		
		File file = new File(path);
		
		try {
			if (!file.exists()) file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void createDirectory(String filePath) {
		File file = new File(filePath);
		File directory = file.getParentFile();
		
		if (!directory.exists()) {
			directory.mkdirs();
		}
	}
	
	public static String readFile(String path) {
		createNewFile(path);
		
		StringBuilder sb = new StringBuilder();
		FileReader fr = null;
		try {
			fr = new FileReader(new File(path));
			
			char[] buff = new char[1024];
			int length = 0;
			
			while ((length = fr.read(buff)) > 0) {
				sb.append(new String(buff, 0, length));
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fr != null) {
				try {
					fr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return sb.toString();
	}
	
	public static void writeFile(String path, String str) {
		createNewFile(path);
		FileWriter fileWriter = null;
		
		try {
			fileWriter = new FileWriter(new File(path), false);
			fileWriter.write(str);
			fileWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fileWriter != null) fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void copyFile(String sourcePath, String destPath) {
		if (!isExistFile(sourcePath)) return;
		createNewFile(destPath);
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream(sourcePath);
			fos = new FileOutputStream(destPath, false);
			
			byte[] buff = new byte[1024];
			int length = 0;
			
			while ((length = fis.read(buff)) > 0) {
				fos.write(buff, 0, length);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void copyDir(String oldPath, String newPath) {
		File oldFile = new File(oldPath);
		File[] files = oldFile.listFiles();
		File newFile = new File(newPath);
		if (!newFile.exists()) {
			newFile.mkdirs();
		}
		for (File file : files) {
			if (file.isFile()) {
				copyFile(file.getPath(), newPath + "/" + file.getName());
			} else if (file.isDirectory()) {
				copyDir(file.getPath(), newPath + "/" + file.getName());
			}
		}
	}
	
	public static void moveFile(String sourcePath, String destPath) {
		copyFile(sourcePath, destPath);
		deleteFile(sourcePath);
	}
	
	public static void deleteFile(String path) {
		File file = new File(path);
		
		if (!file.exists()) return;
		
		if (file.isFile()) {
			file.delete();
			return;
		}
		
		File[] fileArr = file.listFiles();
		
		if (fileArr != null) {
			for (File subFile : fileArr) {
				if (subFile.isDirectory()) {
					deleteFile(subFile.getAbsolutePath());
				}
				
				if (subFile.isFile()) {
					subFile.delete();
				}
			}
		}
		
		file.delete();
	}
	
	public static boolean isExistFile(String path) {
		File file = new File(path);
		return file.exists();
	}
	
	public static void makeDir(String path) {
		if (!isExistFile(path)) {
			File file = new File(path);
			file.mkdirs();
		}
	}
	
	public static void listDir(String path, ArrayList<String> list) {
		File dir = new File(path);
		if (!dir.exists() || dir.isFile()) return;
		
		File[] listFiles = dir.listFiles();
		if (listFiles == null || listFiles.length <= 0) return;
		
		if (list == null) return;
		list.clear();
		for (File file : listFiles) {
			list.add(file.getAbsolutePath());
		}
	}
	
	public static boolean isDirectory(String path) {
		if (!isExistFile(path)) return false;
		return new File(path).isDirectory();
	}
	
	public static boolean isFile(String path) {
		if (!isExistFile(path)) return false;
		return new File(path).isFile();
	}
	
	public static long getFileLength(String path) {
		if (!isExistFile(path)) return 0;
		return new File(path).length();
	}
	
	public static String getFileName(String path) {
		return path.substring(path.lastIndexOf('/') + 1);
	}
	
	public static String getExternalStorageDir() {
		return Environment.getExternalStorageDirectory().getAbsolutePath();
	}
	
	public static String getPackageDataDir(Context context) {
		return context.getExternalFilesDir(null).getAbsolutePath();
	}
	
	public static String getPublicDir(String type) {
		return Environment.getExternalStoragePublicDirectory(type).getAbsolutePath();
	}
    
    public static String convertUriToFilePath(final Context context, final Uri uri) {
        String path = null;
        if (DocumentsContract.isDocumentUri(context, uri)) {
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    path = Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            } else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);

                if (!TextUtils.isEmpty(id)) {
                    if (id.startsWith("raw:")) {
                        return id.replaceFirst("raw:", "");
                    }
                }

                final Uri contentUri = ContentUris
                        .withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                path = getDataColumn(context, contentUri, null, null);
            } else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                path = getDataColumn(context, contentUri, selection, selectionArgs);
            }
        } else if (ContentResolver.SCHEME_CONTENT.equalsIgnoreCase(uri.getScheme())) {
            path = getDataColumn(context, uri, null, null);
        } else if (ContentResolver.SCHEME_FILE.equalsIgnoreCase(uri.getScheme())) {
            path = uri.getPath();
        }

        if (path != null) {
            try {
                return URLDecoder.decode(path, "UTF-8");
            } catch(Exception e) {
                return null;
            }
        }
        return null;
    }

    private static String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {
        final String column = MediaStore.Images.Media.DATA;
        final String[] projection = {
                column
        };

        try (Cursor cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } catch (Exception e) {

        }
        return null;
    }

    private static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    private static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    private static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
	
	public static boolean writeLocalFile(Context context, String filePath, String largeData) {
		try {
			FileOutputStream fos = context.openFileOutput(filePath, Context.MODE_PRIVATE);
			fos.write(largeData.getBytes());
			fos.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static String readLocalFile(Context context, String filePath) {
		try {
			FileInputStream fis = context.openFileInput(filePath);
			StringBuilder data = new StringBuilder();
			int content;
			while ((content = fis.read()) != -1) {
				data.append((char) content);
			}
			fis.close();
			return data.toString();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static boolean existsLocalFile(Context context, String filePath) {
		File file = context.getFileStreamPath(filePath);
		return file != null && file.exists();
	}
	
	public static boolean Unzip(String fileZip, String destDir){
		try {
			File outdir = new File(destDir);
			ZipInputStream zin = new ZipInputStream(new FileInputStream(fileZip));
			ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null) {
				name = entry.getName();
				if(entry.isDirectory()) {
					mkdirs(outdir, name);
					continue;
				}
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (IOException e) {
			return false;
		}
		return true;
		
	}
	
	private static void extractFile(ZipInputStream in, File outdir, String name) throws IOException{
		byte[] buffer = new byte[4096];
		BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(new File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(File outdir, String path){
		File d = new File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name){
		int s = name.lastIndexOf(File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
}
