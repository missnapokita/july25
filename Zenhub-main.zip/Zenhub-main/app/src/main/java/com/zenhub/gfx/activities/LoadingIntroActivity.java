package com.zenhub.gfx.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.elfilibustero.injector.Injector;
import com.elfilibustero.injector.enums.InjectType;
import com.elfilibustero.mlbbdbc.models.BattleEffect;
import com.thekhaeng.pushdownanim.PushDownAnim;
import com.zenhub.gfx.R;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDialog;
import com.zenhub.gfx.databinding.LoadingIntroBinding;
import com.zenhub.gfx.tools.MLBBDatabase;
import com.zenhub.gfx.utils.Config;
import com.zenhub.gfx.utils.SketchwareUtil;

import java.util.ArrayList;
import java.util.List;

public class LoadingIntroActivity extends BaseActivity {

    private LoadingIntroBinding binding;

    private ActivityResultLauncher<Intent> openDocumentTreeLauncher;
    private Injector injector;

    private List<BattleEffect> effects = new ArrayList<>();

    private Intent intent = new Intent();

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = LoadingIntroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();
    }

    private void initialize() {
        effects = getBattleEffectsByType(10);
        injector = new Injector(LoadingIntroActivity.this);
        injector.setPackageName("com.mobile.legends");
        injector.setInjectType(InjectType.fromType(Config.getPermission()));
        injector.setCallback(
                new Injector.Callback() {
                    BaseDialog dialog = new BaseDialog(LoadingIntroActivity.this);
                    LayoutInflater inflater = LayoutInflater.from(LoadingIntroActivity.this);
                    View dialogView = inflater.inflate(R.layout.inject_dialog, null);
                    com.zenhub.gfx.libs.progress.ArcProgressBar progress =
                            dialogView.findViewById(R.id.progress);
                    TextView message = dialogView.findViewById(R.id.message);

                    @Override
                    public void onStart() {
                        dialog.setView(dialogView);
                        dialog.setTitle("Please wait");
                        ((TextView) dialogView.findViewById(R.id.heroName))
                                .setVisibility(View.GONE);
                        message.setText("Checking loading intro...");
                        dialog.setCancelable(false);
                        dialog.show();
                    }

                    @Override
                    public void onFetching(int _progress) {
                        message.setText("Fetching loading intro...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onInjecting(int _progress) {
                        message.setText("Injecting loading intro...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onComplete(Injector.InjectResult _result) {
                        String _errorMessage =
                                _result.getException() != null
                                        ? _result.getException().getMessage()
                                        : "";
                        if (_result.isSuccess()) {
                            SketchwareUtil.showMessage(
                                    getApplicationContext(), "Injecting successfully");
                        } else {
                            SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
                        }
                        showInterstitialAd();
                        dialog.dismiss();
                    }
                });

        binding.imageview1.setOnClickListener(v -> finish());

        binding.searchView.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void onTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {
                        final String _charSeq = _param1.toString();
                        _setupList(MLBBDatabase.filterEffects(_charSeq, effects));
                    }

                    @Override
                    public void beforeTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {}

                    @Override
                    public void afterTextChanged(Editable _param1) {}
                });
        _setupList(effects);
    }

    public void _setupList(final List<BattleEffect> _data) {
        var fXList = binding.fXList;
        var empty = binding.empty;
        if (_data == null || _data.isEmpty()) {
            fXList.setVisibility(View.GONE);
            empty.setVisibility(View.VISIBLE);
            empty.setText("There's no available loading intro");
        } else {
            empty.setVisibility(View.GONE);
            fXList.setVisibility(View.VISIBLE);
            fXList.setAdapter(new FXListAdapter(_data));
        }
    }

    public class FXListAdapter extends RecyclerView.Adapter<FXListAdapter.ViewHolder> {

        List<BattleEffect> _data;

        public FXListAdapter(List<BattleEffect> _arr) {
            _data = _arr;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater _inflater = getLayoutInflater();
            View _v = _inflater.inflate(R.layout.loading_list_item, null);
            RecyclerView.LayoutParams _lp =
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            _v.setLayoutParams(_lp);
            return new ViewHolder(_v);
        }

        @Override
        public void onBindViewHolder(ViewHolder _holder, final int _position) {
            View _view = _holder.itemView;

            final com.google.android.material.card.MaterialCardView cardview1 =
                    _view.findViewById(R.id.cardview1);
            final LinearLayout base = _view.findViewById(R.id.base);
            final com.google.android.material.card.MaterialCardView cardView =
                    _view.findViewById(R.id.cardView);
            final LinearLayout linear1 = _view.findViewById(R.id.linear1);
            final FrameLayout sliderView = _view.findViewById(R.id.sliderView);
            final ImageView imageview2 = _view.findViewById(R.id.imageview2);
            final ImageView play = _view.findViewById(R.id.play);
            final TextView skinName = _view.findViewById(R.id.skinName);
            final Button button1 = _view.findViewById(R.id.button1);

            var effect = _data.get(_position);
            skinName.setText(effect.getName());
            Glide.with(getApplicationContext())
                    .load(Uri.parse(effect.getImage()))
                    .placeholder(R.drawable.default_placeholder)
                    .into(imageview2);

            PushDownAnim.setPushDownAnimTo(cardview1).setScale(PushDownAnim.MODE_STATIC_DP, 4);
            button1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View _view) {
                            if (hasPermission()) {
                                BaseDialog dialog = new BaseDialog(LoadingIntroActivity.this);
                                dialog.setTitle("Notice!");
                                dialog.setMessage(
                                        "Are you sure you want to inject "
                                                + effect.getName()
                                                + "?\n\nClick \"Inject\" to continue.");
                                dialog.setPositiveButton(
                                        "Inject",
                                        v -> {
                                            injector.inject(effect.getScript());
                                            dialog.dismiss();
                                        });
                                dialog.setNegativeButton(
                                        "Cancel",
                                        v -> {
                                            dialog.dismiss();
                                        });
                                dialog.show();
                            } else {
                                checkPermission();
                            }
                        }
                    });
            cardView.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View _view) {
                            BaseDialog dialog = new BaseDialog(LoadingIntroActivity.this);
                            dialog.setTitle("Play");
                            dialog.setMessage(
                                    "Do you wanna see the video of "
                                            + effect.getName()
                                            + "?\n\nClick \"Yes\" to continue.");
                            dialog.setPositiveButton(
                                    "Yes",
                                    v -> {
                                        intent.setClass(
                                                getApplicationContext(), VideoPlayerActivity.class);
                                        intent.putExtra("url", effect.getScript());
                                        startActivity(intent);
                                        dialog.dismiss();
                                    });
                            dialog.setNegativeButton(
                                    "No",
                                    v -> {
                                        dialog.dismiss();
                                    });
                            dialog.show();
                        }
                    });
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View v) {
                super(v);
            }
        }
    }
}
