package com.zenhub.gfx.utils;

import com.zenhub.gfx.tools.PreferenceFactory;

public class Config {

    private static PreferenceFactory preference = PreferenceFactory.getInstance();

    public static int getPermission() {
        return PreferenceFactory.getInstance().readInt("permission", 0);
    }

    public static void setPermission(int permission) {
        PreferenceFactory.getInstance().writeInt("permission", permission);
    }
}
