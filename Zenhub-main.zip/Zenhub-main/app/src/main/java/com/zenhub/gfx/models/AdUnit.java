package com.zenhub.gfx.models;

import com.zenhub.gfx.utils.Constants;

public class AdUnit {

    private String adFormat;
    private String originalAdUnitId;
    private String testAdUnitId;

    public AdUnit(String adFormat, String originalAdUnitId, String testAdUnitId) {
        this.adFormat = adFormat;
        this.originalAdUnitId = originalAdUnitId;
        this.testAdUnitId = testAdUnitId;
    }

    // Getters and setters (optional)
    public static String getUnitIdByAdFormat(String adFormat, boolean useTestIds) {
        AdUnit[] adUnits = {
            // left, right
            // false, true
            // original, test ids
            new AdUnit(
                    Constants.AD_NAME_APP_OPEN,
                    "ca-app-pub-2439589530831816/4246149887",
                    "ca-app-pub-3940256099942544/9257395921"),
            // new AdUnit("Adaptive Banner", "", "ca-app-pub-3940256099942544/9214589741"),
            new AdUnit(
                    "RoleActivity",
                    "ca-app-pub-2439589530831816/6812248255",
                    "ca-app-pub-3940256099942544/1033173712"),
        };

        for (AdUnit adUnit : adUnits) {
            if (adUnit.getAdFormat().equals(adFormat)) {
                return adUnit.getAdUnitId(useTestIds);
            }
        }

        // Return null if the ad format is not found
        return null;
    }

    public String getAdFormat() {
        return adFormat;
    }

    public void setAdFormat(String adFormat) {
        this.adFormat = adFormat;
    }

    // Custom methods to retrieve the unit IDs based on the ad format
    public String getAdUnitId(boolean useTestIds) {
        return useTestIds ? testAdUnitId : originalAdUnitId;
    }

    public String getOriginalAdUnitId() {
        return originalAdUnitId;
    }

    public void setOriginalAdUnitId(String originalAdUnitId) {
        this.originalAdUnitId = originalAdUnitId;
    }

    public String getTestAdUnitId() {
        return testAdUnitId;
    }

    public void setTestAdUnitId(String testAdUnitId) {
        this.testAdUnitId = testAdUnitId;
    }
}
