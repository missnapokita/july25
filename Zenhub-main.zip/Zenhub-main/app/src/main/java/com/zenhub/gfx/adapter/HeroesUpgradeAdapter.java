package com.zenhub.gfx.adapter;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.elfilibustero.mlbbdbc.models.HeroResponse;
import com.elfilibustero.pagination.Paginate;
import com.zenhub.gfx.R;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDiffUtil;
import com.zenhub.gfx.databinding.HeroesUpgradeListItemBinding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HeroesUpgradeAdapter extends RecyclerView.Adapter<HeroesUpgradeAdapter.ViewHolder> {

    BaseActivity activity;
    ArrayList<HashMap<String, Object>> _data;

    public HeroesUpgradeAdapter(BaseActivity activity) {
        this.activity = activity;
        _data = new ArrayList<>();
    }

    public void submitList(ArrayList<HashMap<String, Object>> _arr) {
        var oldList = _data;
        _data = _arr;
        DiffUtil.DiffResult diffResult =
                DiffUtil.calculateDiff(new BaseDiffUtil(_arr, oldList), true);
        diffResult.dispatchUpdatesTo(this);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(
                HeroesUpgradeListItemBinding.inflate(
                        LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder _holder, final int _position) {
        _holder.bind(_data.get(_position));
    }

    @Override
    public int getItemCount() {
        return _data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        HeroesUpgradeListItemBinding binding;
        Paginate paginate;
        boolean isLoading = true;

        public ViewHolder(HeroesUpgradeListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressWarnings("unchecked")
        public void bind(HashMap<String, Object> map) {
            var hero = (HeroResponse.Hero) map.get("hero");
            var skins = (ArrayList<HashMap<String, Object>>) map.get("skins");
            binding.title.setText(hero.getName());
            Glide.with(itemView.getContext())
                    .load(Uri.parse(hero.getIconUrl()))
                    .placeholder(R.drawable.default_placeholder)
                    .into(binding.heroIcon);
            var upgradableAdapter = new UpgradableSkinAdapter(activity);
            binding.list.setAdapter(upgradableAdapter);
            /*
            if (paginate != null) paginate.unbind();
            paginate =
                    Paginate.with(
                                    binding.list,
                                    new Paginate.Callbacks() {
                                        @Override
                                        public void onLoadMore() {
                                            int start = upgradableAdapter.getItemCount();
                                            int end = Math.min(start + 5, skins.size());
                                            isLoading = true;
                                            new Handler(Looper.getMainLooper())
                                                    .postDelayed(
                                                            () -> {
                                                                upgradableAdapter.add(
                                                                        (ArrayList<
                                                                                        HashMap<
                                                                                                String,
                                                                                                Object>>)
                                                                                skins.subList(
                                                                                        start,
                                                                                        end));
                                                                isLoading = false;
                                                            },
                                                            1000);
                                        }

                                        @Override
                                        public boolean isLoading() {
                                            return isLoading;
                                        }

                                        @Override
                                        public boolean hasLoadedAllItems() {
                                            return upgradableAdapter.getItemCount() == skins.size();
                                        }
                                    })
                            .setLoadingTriggerThreshold(1)
                            .addLoadingListItem(true)
                            .build();*/
            upgradableAdapter.submitList(skins);
        }
    }
}
