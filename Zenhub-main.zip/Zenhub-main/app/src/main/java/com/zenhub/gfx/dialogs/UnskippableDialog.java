package com.zenhub.gfx.dialogs;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zenhub.gfx.R;
import com.zenhub.gfx.databinding.UnskippableDialogFragmentBinding;
import com.zenhub.gfx.utils.SketchwareUtil;

import java.util.HashMap;
import java.util.Map;

public class UnskippableDialog extends DialogFragment {

    private UnskippableDialogFragmentBinding binding;
    private Button button1, button2;
    private OnDismissListener onDismissListener;

    private static final String DATA = "data";

    private Map<String, Object> map = new HashMap<>();

    public UnskippableDialog() {}

    public static UnskippableDialog newInstance(String param) {
        UnskippableDialog fragment = new UnskippableDialog();
        Bundle args = new Bundle();
        args.putString(DATA, param);
        fragment.setArguments(args);
        return fragment;
    }

    @NonNull
    @Override
    public View onCreateView(
            @NonNull LayoutInflater _inflater,
            @Nullable ViewGroup _container,
            @Nullable Bundle _savedInstanceState) {
        binding = UnskippableDialogFragmentBinding.inflate(_inflater, _container, false);
        initialize();
        return binding.getRoot();
    }

    private void initialize() {
        if (getArguments() != null) {
            try {
                map =
                        new Gson()
                                .fromJson(
                                        getArguments().getString(DATA),
                                        new TypeToken<HashMap<String, Object>>() {}.getType());
            } catch (Exception e) {
                map = new HashMap<>();
                SketchwareUtil.showMessage(requireContext(), e.toString());
            }
        }
        button1 = binding.button1;
        button2 = binding.button2;

        setCancelable(false);
        if (!map.isEmpty()) {
            Glide.with(getContext().getApplicationContext())
                    .load(Uri.parse(map.get("image").toString()))
                    .into(binding.landscape);
            button1.setText(map.get("but1").toString());
            button2.setText(map.get("but2").toString());
        }
        button1.setOnClickListener(
                v -> {
                    _openUrl(map.get("l1").toString());
                    button1.setAlpha((float) (0.3d));
                    button1.setEnabled(false);
                });

        button2.setOnClickListener(
                v -> {
                    _openUrl(map.get("l2").toString());
                    button2.setAlpha((float) (0.3d));
                    button2.setEnabled(false);
                });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!button1.isEnabled() && !button2.isEnabled()) {
            dismiss();
        }
    }

    @Override
    public int getTheme() {
        return R.style.UnskippableBottomSheetTheme;
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public void setOnDismissListener(OnDismissListener listener) {
        this.onDismissListener = listener;
    }

    public interface OnDismissListener {
        void onDismiss();
    }

    public void _openUrl(final String _url) {
        try {
            Intent open = new Intent(Intent.ACTION_VIEW);
            open.setData(Uri.parse(_url));
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(open);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }
}
