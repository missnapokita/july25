package com.zenhub.gfx.tools;

import java.util.ArrayList;
import java.util.HashMap;

public class SkinRepository {
    private static SkinRepository instance;
    
    private ArrayList<HashMap<String, Object>> assassins = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> fighters = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> mages = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> marksmans = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> supports = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> tanks = new ArrayList<>();

    private SkinRepository() {}

    public static synchronized SkinRepository getInstance() {
        if (instance == null) {
            instance = new SkinRepository();
        }
        return instance;
    }
}
