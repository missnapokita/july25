package com.zenhub.gfx.activities;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.zenhub.gfx.R;
import com.zenhub.gfx.adapter.HeroesUpgradeAdapter;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.databinding.UpgradeBinding;
import com.zenhub.gfx.dialogs.UpgradeDialog;
import com.zenhub.gfx.tools.MLBBDatabase;

import com.zenhub.gfx.utils.Constants;
import java.util.ArrayList;
import java.util.HashMap;

public class UpgradeActivity extends BaseActivity
        implements UpgradeDialog.RequestPermissionListener {

    private UpgradeBinding binding;

    private String role = "Assassin";

    private ArrayList<HashMap<String, Object>> skins = new ArrayList<>();

    private RecyclerView heroList;
    private HeroesUpgradeAdapter adapter;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = UpgradeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();
    }

    private void initialize() {
        adapter = new HeroesUpgradeAdapter(this);
        heroList = binding.heroList;
        heroList.setAdapter(adapter);
        
        skins = getUpgradedSkins();

        binding.imageview1.setOnClickListener(v -> finish());

        var searchView = binding.searchView;

        binding.spinner1.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> _param1, View _param2, int _param3, long _param4) {
                        final int _position = _param3;
                        searchView.setText("");
                        role = Constants.ROLES[_position];
                        skins = getUpgradedSkinsOf(role);
                        binding.imageview3.setImageResource(MLBBDatabase.getRoleIconByType(role));
                        _setupList(skins);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> _param1) {}
                });

        searchView.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void onTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {
                        final String _charSeq = _param1.toString();
                        _setupList(MLBBDatabase.filterSkin(_charSeq, skins));
                    }

                    @Override
                    public void beforeTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {}

                    @Override
                    public void afterTextChanged(Editable _param1) {}
                });

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, R.layout.spinner_dropdown_item, Constants.ROLES) {
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        TextView textView = (TextView) super.getView(position, convertView, parent);
                        var role = textView.getText().toString();
                        textView.setTextColor(
                                switch (role) {
                                    case "Assassin" -> Color.parseColor("#ab47bc");
                                    case "Fighter" -> Color.parseColor("#f44336");
                                    case "Mage" -> Color.parseColor("#2196f3");
                                    case "Marksman" -> Color.parseColor("#ffeb3b");
                                    case "Support" -> Color.parseColor("#00BCD4");
                                    case "Tank" -> Color.parseColor("#ffc107");
                                    default -> Color.WHITE;
                                });
                        textView.setTextSize(10.0f);
                        textView.setGravity(Gravity.CENTER);
                        textView.setTypeface(
                                Typeface.createFromAsset(
                                        UpgradeActivity.this.getAssets(), "fonts/default_font.ttf"),
                                0);
                        textView.setPadding(0, 0, 0, 0);
                        return textView;
                    }
                };
        var spinner1 = binding.spinner1;
        spinner1.setAdapter(adapter);
        spinner1.setSelection(getSelectedRole(role));
        _setupList(skins);
        searchView.setAdapter(
                new ArrayAdapter<String>(
                        getBaseContext(), android.R.layout.simple_list_item_1, getHeroNames()));
    }

    public void _setupList(final ArrayList<HashMap<String, Object>> _map) {
        var empty = binding.empty;
        if (_map == null || _map.isEmpty()) {
            heroList.setVisibility(View.GONE);
            empty.setVisibility(View.VISIBLE);
            empty.setText("There's no upgradable skins for ".concat(role));
        } else {
            empty.setVisibility(View.GONE);
            heroList.setVisibility(View.VISIBLE);
            adapter.submitList(_map);
        }
    }

    @Override
    public void onRequestPermission() {
        checkPermission();
    }

    @Override
    public boolean permissionGranted() {
        return hasPermission();
    }
}
