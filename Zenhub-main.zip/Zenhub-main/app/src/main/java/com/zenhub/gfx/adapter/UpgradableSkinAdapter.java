package com.zenhub.gfx.adapter;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.elfilibustero.mlbbdbc.models.UpgradeSkin;
import com.google.gson.Gson;
import com.zenhub.gfx.R;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDiffUtil;
import com.zenhub.gfx.databinding.HeroesSkinListItemBinding;
import com.zenhub.gfx.dialogs.UpgradeDialog;

import java.util.ArrayList;
import java.util.HashMap;

public class UpgradableSkinAdapter extends RecyclerView.Adapter<UpgradableSkinAdapter.ViewHolder> {

    BaseActivity activity;
    ArrayList<HashMap<String, Object>> _data;

    public UpgradableSkinAdapter(BaseActivity activity) {
        this.activity = activity;
        _data = new ArrayList<>();
    }

    public void submitList(ArrayList<HashMap<String, Object>> _arr) {
        /*
        var oldList = _data;
        _data = _arr;
        DiffUtil.DiffResult diffResult =
                DiffUtil.calculateDiff(new BaseDiffUtil(_arr, oldList), true);
        diffResult.dispatchUpdatesTo(this);
        */
        DiffUtil.DiffResult diffResult =
                DiffUtil.calculateDiff(new BaseDiffUtil(_arr, _data), true);
        _data.clear();
        _data.addAll(_arr);
        try {
            diffResult.dispatchUpdatesTo(this);
        } catch (IndexOutOfBoundsException e) {
            notifyDataSetChanged();
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(
                HeroesSkinListItemBinding.inflate(
                        LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder _holder, final int _position) {
        _holder.bind(_data.get(_position));
    }

    @Override
    public int getItemCount() {
        return _data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        HeroesSkinListItemBinding binding;

        public ViewHolder(HeroesSkinListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(HashMap<String, Object> map) {
            var skin = (UpgradeSkin) map.get("skin");
            var hero = activity.getHeroFrom(skin.getHeroId());
            binding.title.setText(skin.getSkinName());
            Glide.with(itemView.getContext())
                    .load(Uri.parse(skin.getImage()))
                    .placeholder(R.drawable.placeholder)
                    .into(binding.portrait);

            itemView.setOnClickListener(
                    v -> {
                        UpgradeDialog bottomSheetDialog =
                                UpgradeDialog.newInstance(new Gson().toJson(map));
                        bottomSheetDialog.show(
                                activity.getSupportFragmentManager(), "ElfilibusteroSakalam");
                        // activity.showInterstitialAd();
                    });
        }
    }
}
