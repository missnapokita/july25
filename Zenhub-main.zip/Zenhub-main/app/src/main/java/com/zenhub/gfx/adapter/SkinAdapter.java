package com.zenhub.gfx.adapter;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.elfilibustero.injector.Injector;
import com.elfilibustero.injector.enums.InjectType;
import com.elfilibustero.mlbbdbc.models.Skin;
import com.elfilibustero.skintag.SkinTag;
import com.zenhub.gfx.R;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDialog;
import com.zenhub.gfx.base.BaseDiffUtil;
import com.zenhub.gfx.databinding.HeroesSkinListItemBinding;
import com.zenhub.gfx.databinding.InjectDialogBinding;
import com.zenhub.gfx.tools.HistoryRepository;
import com.zenhub.gfx.utils.Config;
import com.zenhub.gfx.utils.SketchwareUtil;

import java.util.ArrayList;
import java.util.List;

public class SkinAdapter extends RecyclerView.Adapter<SkinAdapter.ViewHolder> {

    BaseActivity activity;
    List<Skin> _data;

    public SkinAdapter(BaseActivity activity) {
        this.activity = activity;
        _data = new ArrayList<>();
    }

    public void submitList(List<Skin> _arr) {
        var oldList = _data;
        _data = _arr;
        DiffUtil.DiffResult diffResult =
                DiffUtil.calculateDiff(new BaseDiffUtil(_arr, oldList), true);
        diffResult.dispatchUpdatesTo(this);
    }

    public void add(List<Skin> list) {
        _data.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(
                HeroesSkinListItemBinding.inflate(
                        LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder _holder, final int _position) {
        _holder.bind(_data.get(_position));
    }

    @Override
    public int getItemCount() {
        return _data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        HeroesSkinListItemBinding binding;

        public ViewHolder(HeroesSkinListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Skin skin) {
            var hero = activity.getHeroFrom(skin.getHeroId());
            binding.title.setText(skin.getSkinName());
            Glide.with(itemView.getContext())
                    .load(Uri.parse(skin.getSkinPortrait()))
                    .placeholder(R.drawable.placeholder)
                    .into(binding.portrait);
            binding.skinTag.setImageResource(SkinTag.getSkinTagFrom(skin.getSkinType()));

            itemView.setOnClickListener(
                    view -> {
                        if (activity.hasPermission()) {
                            BaseDialog dialog = new BaseDialog(activity);
                            dialog.setTitle("Notice!");
                            dialog.setMessage(
                                    "Are you sure you want to inject "
                                            + hero.getName()
                                            + "`s "
                                            + skin.getSkinName()
                                            + " skin?\n\nClick \"Inject\" to continue.",
                                    true);
                            dialog.setPositiveButton(
                                    "Inject",
                                    v -> {
                                        new HistoryRepository(activity).addSkin(skin);
                                        inject(skin);
                                        dialog.dismiss();
                                    });
                            dialog.setNegativeButton(
                                    "Cancel",
                                    v -> {
                                        dialog.dismiss();
                                    });
                            dialog.show();
                        } else {
                            activity.checkPermission();
                        }
                    });
        }

        private void inject(final Skin skin) {
            Injector injector = new Injector(activity);
            injector.setPackageName("com.mobile.legends");
            injector.setInjectType(InjectType.fromType(Config.getPermission()));
            injector.setCallback(
                    new Injector.Callback() {
                        BaseDialog dialog = new BaseDialog(activity);
                        InjectDialogBinding dialogBinding =
                                InjectDialogBinding.inflate(activity.getLayoutInflater());

                        @Override
                        public void onStart() {
                            dialog.setView(dialogBinding.getRoot());
                            dialog.setTitle("Please wait");
                            var hero = activity.getHeroFrom(skin.getHeroId());
                            dialogBinding.heroName.setText(hero.getName());
                            dialogBinding.message.setText(
                                    "Injecting " + skin.getSkinName() + "...");
                            dialog.setCancelable(false);
                            dialog.show();
                        }

                        @Override
                        public void onFetching(int _progress) {
                            dialogBinding.message.setText("Fetching " + skin.getSkinName() + "...");
                            dialogBinding.progress.setProgress(_progress);
                        }

                        @Override
                        public void onInjecting(int _progress) {
                            dialogBinding.message.setText(
                                    "Injecting " + skin.getSkinName() + "...");
                            dialogBinding.progress.setProgress(_progress);
                        }

                        @Override
                        public void onComplete(Injector.InjectResult _result) {
                            String _errorMessage =
                                    _result.getException() != null
                                            ? _result.getException().getMessage()
                                            : "";
                            if (_result.isSuccess()) {
                                SketchwareUtil.showMessage(activity, "Injecting successfully");
                                activity.showInterstitialAd();
                            } else {
                                SketchwareUtil.showMessage(activity, _errorMessage);
                            }
                            dialog.dismiss();
                        }
                    });
            injector.inject(skin.getSkinScript());
        }
    }
}
