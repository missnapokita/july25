package com.zenhub.gfx.activities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.elfilibustero.injector.Injector;
import com.elfilibustero.injector.enums.InjectType;
import com.elfilibustero.mlbbdbc.models.BattleEffect;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zenhub.gfx.R;
import com.zenhub.gfx.adapter.BattleEffectAdapter;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDialog;
import com.zenhub.gfx.databinding.BattleEffectBinding;
import com.zenhub.gfx.tools.HistoryRepository;
import com.zenhub.gfx.tools.MLBBDatabase;
import com.zenhub.gfx.utils.Config;
import com.zenhub.gfx.utils.SketchwareUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BattleEffectActivity extends BaseActivity {

    private BattleEffectBinding binding;

    private HashMap<String, Object> map = new HashMap<>();
    private Injector injector;

    private List<BattleEffect> effects = new ArrayList<>();

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = BattleEffectBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();
        initializeLogic();
    }

    private void initialize() {
        map =
                new Gson()
                        .fromJson(
                                getIntent().getStringExtra("effect"),
                                new TypeToken<HashMap<String, Object>>() {}.getType());
        effects = getBattleEffectsByType((int) (double) map.get("type"));

        injector = new Injector(BattleEffectActivity.this);
        injector.setPackageName("com.mobile.legends");
        injector.setInjectType(InjectType.fromType(Config.getPermission()));

        binding.imageview1.setOnClickListener(v -> finish());

        binding.searchView.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void onTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {
                        final String _charSeq = _param1.toString();
                        _setupList(MLBBDatabase.filterEffects(_charSeq, effects));
                    }

                    @Override
                    public void beforeTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {}

                    @Override
                    public void afterTextChanged(Editable _param1) {}
                });
    }

    private void initializeLogic() {
        _setupList(effects);
        if (getIntent().hasExtra("name")) {
            binding.searchView.requestFocus();
            binding.searchView.setText(getIntent().getStringExtra("name"));
        }
    }

    public void _setupList(final List<BattleEffect> _data) {
        var fXList = binding.fXList;
        var empty = binding.empty;
        if (_data == null || _data.isEmpty()) {
            fXList.setVisibility(View.GONE);
            empty.setVisibility(View.VISIBLE);
            empty.setText(
                    "There's no available battle effect for ".concat(map.get("name").toString()));
        } else {
            empty.setVisibility(View.GONE);
            fXList.setVisibility(View.VISIBLE);
            var adapter = new BattleEffectAdapter(this, _data);
            adapter.setOnInjectListener(
                    effect -> {
                        new HistoryRepository(BattleEffectActivity.this).addEffect(effect);
                        _updateCallback();
                        injector.inject(effect.getScript());
                    });
            fXList.setAdapter(adapter);
        }
    }

    public void _updateCallback() {
        injector.setCallback(
                new Injector.Callback() {
                    BaseDialog dialog = new BaseDialog(BattleEffectActivity.this);
                    LayoutInflater inflater = LayoutInflater.from(BattleEffectActivity.this);
                    View dialogView = inflater.inflate(R.layout.inject_dialog, null);
                    com.zenhub.gfx.libs.progress.ArcProgressBar progress =
                            dialogView.findViewById(R.id.progress);
                    TextView message = dialogView.findViewById(R.id.message);
                    BattleEffect effect =
                            new HistoryRepository(BattleEffectActivity.this).getLatestEffect();

                    @Override
                    public void onStart() {
                        dialog.setView(dialogView);
                        dialog.setTitle("Please wait");
                        ((TextView) dialogView.findViewById(R.id.heroName))
                                .setText(effect.getName());
                        dialog.setCancelable(false);
                        dialog.show();
                    }

                    @Override
                    public void onFetching(int _progress) {
                        message.setText("Fetching...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onInjecting(int _progress) {
                        message.setText("Injecting...");
                        progress.setProgress(_progress);
                    }

                    @Override
                    public void onComplete(Injector.InjectResult _result) {
                        String _errorMessage =
                                _result.getException() != null
                                        ? _result.getException().getMessage()
                                        : "";
                        if (_result.isSuccess()) {
                            SketchwareUtil.showMessage(
                                    getApplicationContext(), "Injecting successfully");
                        } else {
                            SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
                        }
                        showInterstitialAd();
                        dialog.dismiss();
                    }
                });
    }
}
