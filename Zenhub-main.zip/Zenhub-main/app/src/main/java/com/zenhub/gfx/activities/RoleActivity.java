package com.zenhub.gfx.activities;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.elfilibustero.mlbbdbc.models.Skin;
import com.elfilibustero.pagination.Paginate;
import com.google.android.material.chip.Chip;
import com.google.gson.Gson;
import com.thekhaeng.pushdownanim.PushDownAnim;
import com.zenhub.gfx.R;
import com.zenhub.gfx.adapter.HeroesAdapter;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.databinding.RoleBinding;
import com.zenhub.gfx.tools.MLBBDatabase;

import com.zenhub.gfx.utils.Constants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RoleActivity extends BaseActivity {

    private RoleBinding binding;

    private String role = "";
    private HashMap<String, Object> map = new HashMap<>();

    private int category = 0;
    private String customType = "";

    private ArrayList<HashMap<String, Object>> skins = new ArrayList<>();

    private Intent i = new Intent();
    private AlertDialog.Builder dialog;

    private RecyclerView roleList;
    private HeroesAdapter heroesAdapter;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = RoleBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();
        initializeLogic();
    }

    private void initialize() {
        if (!getIntent().hasExtra("role")) {
            finish();
            return;
        }
        role = getIntent().getStringExtra("role");
        dialog = new AlertDialog.Builder(this);

        roleList = binding.roleList;

        heroesAdapter = new HeroesAdapter(this);
        roleList.setAdapter(heroesAdapter);

        binding.imageview1.setOnClickListener(v -> finish());

        var searchView = binding.searchView;

        binding.spinner1.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> _param1, View _param2, int _position, long _param4) {
                        role = Constants.ROLES[_position];
                        binding.imageview3.setImageResource(MLBBDatabase.getRoleIconByType(role));
                        if (customType.isEmpty()) {
                            skins = getSkinsByCategory(role, category);
                        } else {
                            skins = getSkinsOf(role, category, customType);
                        }
                        _setupList(skins);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> _param1) {}
                });

        binding.searchView.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void onTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {
                        final String _charSeq = _param1.toString();
                        _setupList(MLBBDatabase.filterSkin(_charSeq, skins));
                    }

                    @Override
                    public void beforeTextChanged(
                            CharSequence _param1, int _param2, int _param3, int _param4) {}

                    @Override
                    public void afterTextChanged(Editable _param1) {}
                });

        binding.official.setOnClickListener(this::updateList);
        binding.custom.setOnClickListener(this::updateList);
        binding.swap.setOnClickListener(this::updateList);

        binding.old.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        category = (int) binding.custom.getTag();
                        customType = "Old";
                        searchView.setText("");
                        skins = getSkinsOf(role, category, customType);
                        _setupList(skins);
                    }
                });

        binding.anime.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        category = (int) binding.custom.getTag();
                        customType = "Anime";
                        searchView.setText("");
                        skins = getSkinsOf(role, category, customType);
                        _setupList(skins);
                    }
                });
    }

    private void initializeLogic() {
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, R.layout.spinner_dropdown_item, Constants.ROLES) {
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        TextView textView = (TextView) super.getView(position, convertView, parent);
                        var role = textView.getText().toString();
                        textView.setTextColor(
                                switch (role) {
                                    case "Assassin" -> Color.parseColor("#ab47bc");
                                    case "Fighter" -> Color.parseColor("#f44336");
                                    case "Mage" -> Color.parseColor("#2196f3");
                                    case "Marksman" -> Color.parseColor("#ffeb3b");
                                    case "Support" -> Color.parseColor("#00BCD4");
                                    case "Tank" -> Color.parseColor("#ffc107");
                                    default -> Color.WHITE;
                                });
                        textView.setTextSize(10.0f);
                        textView.setGravity(Gravity.CENTER);
                        textView.setTypeface(
                                Typeface.createFromAsset(getAssets(), "fonts/default_font.ttf"), 0);
                        textView.setPadding(0, 0, 0, 0);
                        return textView;
                    }
                };
        binding.spinner1.setAdapter(adapter);
        binding.spinner1.setSelection(getSelectedRole(role));
        _setChipTags();
        if (getIntent().hasExtra("history")) {
            var history = new Gson().fromJson(getIntent().getStringExtra("history"), Skin.class);
            var chip = (Chip) binding.chipGroup.findViewWithTag(history.getSkinCategory());
            if (chip != null) chip.performClick();
        } else {
            skins = getSkinsByCategory(role, 0);
        }
        _setupList(skins);
    }

    private boolean isLoading = false;

    private Paginate paginate;

    private void updatePagination(ArrayList<HashMap<String, Object>> skins) {
        if (paginate != null) paginate.unbind();
        paginate =
                Paginate.with(
                                binding.roleList,
                                new Paginate.Callbacks() {
                                    @Override
                                    public void onLoadMore() {
                                        int start = heroesAdapter.getItemCount();
                                        int end = Math.min(start + 5, skins.size());
                                        isLoading = true;
                                        new Handler(Looper.getMainLooper())
                                                .postDelayed(
                                                        () -> {
                                                            heroesAdapter.add(
                                                                    (ArrayList<
                                                                                    HashMap<
                                                                                            String,
                                                                                            Object>>)
                                                                            skins.subList(
                                                                                    start, end));
                                                            isLoading = false;
                                                        },
                                                        1000);
                                    }

                                    @Override
                                    public boolean isLoading() {
                                        return isLoading;
                                    }

                                    @Override
                                    public boolean hasLoadedAllItems() {
                                        return heroesAdapter.getItemCount() == skins.size();
                                    }
                                })
                        .setLoadingTriggerThreshold(2)
                        .addLoadingListItem(true)
                        .build();
    }

    private void updateList(View view) {
        category = (int) view.getTag();
        customType = "";
        binding.searchView.setText("");
        skins = getSkinsByCategory(role, category);
        _setupList(skins);
    }

    @SuppressWarnings("deprecation")
    public void _spannableAppName() {
        SpannableString spannableString = new SpannableString("  " + role);

        Drawable icon = getResources().getDrawable(MLBBDatabase.getRoleIconByType(role));
        icon.setBounds(0, 0, 50, 50);

        var imageSpan = new com.zenhub.gfx.libs.spannable.CenteredImageSpan(icon);
        spannableString.setSpan(imageSpan, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);

        getSupportActionBar().setTitle(spannableString);
    }

    @SuppressWarnings("deprecation")
    public void _setRole(final TextView _textView, final String _role) {
        SpannableString spannableString = new SpannableString("  " + _role);

        Drawable icon = getResources().getDrawable(MLBBDatabase.getRoleIconByType(role));
        icon.setBounds(0, 0, 50, 50);

        var imageSpan = new com.zenhub.gfx.libs.spannable.CenteredImageSpan(icon);
        spannableString.setSpan(imageSpan, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);

        _textView.setText(spannableString);
    }

    public void _setupList(final ArrayList<HashMap<String, Object>> _map) {
        var empty = binding.empty;
        if (_map == null || _map.isEmpty()) {
            roleList.setVisibility(View.GONE);
            empty.setVisibility(View.VISIBLE);
            empty.setText(
                    "There's no available hero for "
                            .concat(Constants.ROLES[binding.spinner1.getSelectedItemPosition()]));
        } else {
            empty.setVisibility(View.GONE);
            roleList.setVisibility(View.VISIBLE);
            heroesAdapter.submitList(_map);
        }
    }

    public void _setChipTags() {
        binding.official.setTag(0);
        binding.custom.setTag(1);
        binding.swap.setTag(3);
        for (int i = 0; i < binding.chipGroup.getChildCount(); i++) {
            PushDownAnim.setPushDownAnimTo(binding.chipGroup.getChildAt(i))
                    .setScale(PushDownAnim.MODE_STATIC_DP, 4);
        }
    }
}
