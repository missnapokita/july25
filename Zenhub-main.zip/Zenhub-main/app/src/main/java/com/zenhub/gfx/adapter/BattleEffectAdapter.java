package com.zenhub.gfx.adapter;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.elfilibustero.mlbbdbc.models.BattleEffect;
import com.thekhaeng.pushdownanim.PushDownAnim;
import com.zenhub.gfx.R;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDialog;
import com.zenhub.gfx.databinding.BattleEffectListItemBinding;

import java.util.List;

public class BattleEffectAdapter extends RecyclerView.Adapter<BattleEffectAdapter.ViewHolder> {

    BaseActivity activity;
    List<BattleEffect> _data;

    public BattleEffectAdapter(BaseActivity activity, List<BattleEffect> _arr) {
        this.activity = activity;
        _data = _arr;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        BattleEffectListItemBinding binding =
                BattleEffectListItemBinding.inflate(
                        LayoutInflater.from(parent.getContext()), parent, false);
        View _v = binding.getRoot();
        RecyclerView.LayoutParams _lp =
                new RecyclerView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        _v.setLayoutParams(_lp);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewHolder _holder, final int _position) {
        var binding = _holder.binding;
        var effect = _data.get(_position);
        binding.title.setText(effect.getName());
        Glide.with(activity)
                .load(Uri.parse(effect.getImage()))
                .placeholder(R.drawable.default_placeholder)
                .into(binding.imageview1);

        PushDownAnim.setPushDownAnimTo(binding.cardview1)
                .setScale(PushDownAnim.MODE_STATIC_DP, 4)
                .setOnClickListener(
                        view -> {
                            if (activity.hasPermission()) {
                                BaseDialog dialog = new BaseDialog(activity);
                                dialog.setTitle("Notice!");
                                dialog.setMessage(
                                        "Are you sure you want to inject "
                                                + effect.getName()
                                                + "?\n\nClick \"Inject\" to continue.",
                                        true);
                                dialog.setPositiveButton(
                                        "Inject",
                                        v -> {
                                            if (listener != null) {
                                                listener.onInject(effect);
                                            }
                                            dialog.dismiss();
                                        });
                                dialog.setNegativeButton(
                                        "Cancel",
                                        v -> {
                                            dialog.dismiss();
                                        });
                                dialog.show();
                            } else {
                                activity.checkPermission();
                            }
                        });
    }

    @Override
    public int getItemCount() {
        return _data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        BattleEffectListItemBinding binding;

        public ViewHolder(BattleEffectListItemBinding v) {
            super(v.getRoot());
            binding = v;
        }
    }

    public interface InjectListener {

        void onInject(BattleEffect effect);
    }

    private InjectListener listener;

    public void setOnInjectListener(InjectListener listener) {
        this.listener = listener;
    }
}
