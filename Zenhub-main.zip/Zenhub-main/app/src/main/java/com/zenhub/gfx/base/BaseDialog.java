package com.zenhub.gfx.base;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.core.text.HtmlCompat;

import com.zenhub.gfx.R;
import com.zenhub.gfx.databinding.DialogBinding;

public class BaseDialog extends Dialog {

    private DialogBinding binding;

    private int dialogImageResId = -1;
    private String dialogTitleText = "";
    private String dialogMessageText = "";
    private boolean normalMessage = false;
    private View dialogCustomView;
    private View dialogButtonsContainer;
    private String dialogDefaultText = "Default";
    private View.OnClickListener dialogDefaultListener = null;
    private String dialogNoText = "No";
    private View.OnClickListener dialogNoListener = null;
    private String dialogYesText = "Yes";
    private View.OnClickListener dialogYesListener = null;

    public BaseDialog(Activity activity) {
        super(activity, R.style.TransparentDialog);
    }

    /** Set the dialog's image's resource ID */
    public BaseDialog setIcon(@DrawableRes int resId) {
        dialogImageResId = resId;
        return this;
    }

    /** Set the dialog's custom view */
    public BaseDialog setView(View customView) {
        dialogCustomView = customView;
        return this;
    }

    /** Set the dialog's message */
    public BaseDialog setMessage(String message) {
        dialogMessageText = message;
        return this;
    }

    /** Set the dialog's message */
    public BaseDialog setMessage(String message, boolean normal) {
        dialogMessageText = message;
        normalMessage = normal;
        return this;
    }

    /** Set the dialog's "No" button text and listener */
    public BaseDialog setNegativeButton(String noText, View.OnClickListener noListener) {
        dialogNoText = noText;
        dialogNoListener = noListener;
        return this;
    }

    /** Set the dialog's title */
    public BaseDialog setTitle(String title) {
        dialogTitleText = title;
        return this;
    }

    /** Set the dialog's "Yes" button text and listener */
    public BaseDialog setPositiveButton(String yesText, View.OnClickListener yesListener) {
        dialogYesText = yesText;
        dialogYesListener = yesListener;
        return this;
    }

    public BaseDialog setDefaultButton(String defaultText, View.OnClickListener defaultListener) {
        dialogDefaultText = defaultText;
        dialogDefaultListener = defaultListener;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // getWindow().setBackgroundDrawableResource(R.drawable.custom_dialog_inset_white);

        {
            var attributes = getWindow().getAttributes();
            attributes.width = ViewGroup.LayoutParams.MATCH_PARENT;
            getWindow().setAttributes(attributes);
        }
        binding = DialogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ImageView dialogImage = binding.dialogImg;
        TextView dialogTitle = binding.dialogTitle;
        TextView dialogMessage = binding.dialogMsg;
        FrameLayout dialogCustomViewContainer = binding.customView;

        dialogButtonsContainer = binding.layoutButton;
        TextView dialogDefault = binding.commonDialogDefaultButton;
        dialogDefault.setText(dialogDefaultText);
        dialogDefault.setOnClickListener(dialogDefaultListener);
        TextView dialogNo = binding.dialogBtnNo;
        dialogNo.setText(dialogNoText);
        dialogNo.setOnClickListener(dialogNoListener);
        TextView dialogYes = binding.dialogBtnYes;
        dialogYes.setText(dialogYesText);
        dialogYes.setOnClickListener(dialogYesListener);

        if (dialogTitleText.isEmpty()) {
            dialogTitle.setVisibility(View.GONE);
        } else {
            dialogTitle.setVisibility(View.VISIBLE);
            dialogTitle.setText(dialogTitleText);
        }

        if (dialogMessageText.isEmpty()) {
            dialogMessage.setVisibility(View.GONE);
        } else {
            dialogMessage.setVisibility(View.VISIBLE);
            dialogMessage.setText(
                    !normalMessage
                            ? HtmlCompat.fromHtml(
                                    dialogMessageText, HtmlCompat.FROM_HTML_MODE_LEGACY)
                            : dialogMessageText);
        }

        if (dialogDefaultListener == null) {
            dialogDefault.setVisibility(View.GONE);
        }

        if (dialogNoListener == null) {
            dialogNo.setVisibility(View.GONE);
        }

        if (dialogYesListener == null) {
            dialogYes.setVisibility(View.GONE);
        }

        if (dialogImageResId == -1) {
            dialogImage.setVisibility(View.GONE);
        } else {
            dialogImage.setImageResource(dialogImageResId);
        }

        if (dialogCustomView != null) {
            dialogCustomViewContainer.setVisibility(View.VISIBLE);
            dialogCustomViewContainer.addView(dialogCustomView);
        } else {
            dialogCustomViewContainer.setVisibility(View.GONE);
        }
    }

    @Override
    public void show() {
        super.show();
        if (dialogDefaultListener == null
                && dialogYesListener == null
                && dialogNoListener == null) {
            if (dialogButtonsContainer != null) {
                dialogButtonsContainer.setVisibility(View.GONE);
            }
        }
    }
}
