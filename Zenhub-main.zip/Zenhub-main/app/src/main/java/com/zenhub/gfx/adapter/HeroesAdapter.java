package com.zenhub.gfx.adapter;

import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.elfilibustero.mlbbdbc.models.HeroResponse;
import com.elfilibustero.mlbbdbc.models.Skin;
import com.elfilibustero.pagination.Paginate;
import com.zenhub.gfx.base.BaseActivity;
import com.zenhub.gfx.base.BaseDiffUtil;
import com.zenhub.gfx.databinding.HeroesListItemBinding;
import com.zenhub.gfx.tools.MLBBDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HeroesAdapter extends RecyclerView.Adapter<HeroesAdapter.ViewHolder> {

    BaseActivity activity;
    ArrayList<HashMap<String, Object>> _data;

    public HeroesAdapter(BaseActivity activity) {
        this.activity = activity;
        _data = new ArrayList<>();
    }

    public void submitList(ArrayList<HashMap<String, Object>> _arr) {
        var oldList = _data;
        _data = _arr;
        DiffUtil.DiffResult diffResult =
                DiffUtil.calculateDiff(new BaseDiffUtil(_arr, oldList), true);
        diffResult.dispatchUpdatesTo(this);
    }

    public void add(ArrayList<HashMap<String, Object>> list) {
        _data.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(
                HeroesListItemBinding.inflate(
                        LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder _holder, final int _position) {
        _holder.bind(_data.get(_position));
    }

    @Override
    public int getItemCount() {
        return _data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        HeroesListItemBinding binding;
        Paginate paginate;
        boolean isLoading = false;

        public ViewHolder(HeroesListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressWarnings("unchecked")
        public void bind(HashMap<String, Object> map) {
            var hero = (HeroResponse.Hero) map.get("hero");
            var skins = (List<Skin>) map.get("skins");
            _setRole(binding.title, hero.getName());
            var skinAdapter = new SkinAdapter(activity);
            binding.list.setAdapter(skinAdapter);
            try {
                if (paginate != null) paginate.unbind();
                paginate =
                        Paginate.with(
                                        binding.list,
                                        new Paginate.Callbacks() {
                                            @Override
                                            public void onLoadMore() {
                                                int start = skinAdapter.getItemCount();
                                                int end = Math.min(start + 5, skins.size());
                                                isLoading = true;
                                                new Handler(Looper.getMainLooper())
                                                        .postDelayed(
                                                                () -> {
                                                                    skinAdapter.add(
                                                                            skins.subList(
                                                                                    start, end));
                                                                    isLoading = false;
                                                                },
                                                                1000);
                                            }

                                            @Override
                                            public boolean isLoading() {
                                                return isLoading;
                                            }

                                            @Override
                                            public boolean hasLoadedAllItems() {
                                                return skinAdapter.getItemCount() == skins.size();
                                            }
                                        })
                                .setLoadingTriggerThreshold(1)
                                .addLoadingListItem(true)
                                .build();
            } catch (Exception e) {
                skinAdapter.submitList(skins);
            }
        }

        @SuppressWarnings("deprecation")
        public void _setRole(final TextView _textView, final String name) {
            SpannableString spannableString = new SpannableString("  " + name);

            Drawable icon =
                    itemView.getContext()
                            .getResources()
                            .getDrawable(MLBBDatabase.getRoleIconByType(name));
            icon.setBounds(0, 0, 50, 50);

            var imageSpan = new com.zenhub.gfx.libs.spannable.CenteredImageSpan(icon);
            spannableString.setSpan(imageSpan, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);

            _textView.setText(spannableString);
        }
    }
}
