plugins {
    id("com.android.application")
}

import java.util.Properties

val anyIpProperties = Properties()
val anyIpPropertiesFile = rootProject.file("anyip.properties")

if (anyIpPropertiesFile.exists()) {
    anyIpPropertiesFile.bufferedReader(Charsets.UTF_8).use { reader ->
        anyIpProperties.load(reader)
    }
}

android {
    namespace = "com.zenhub.gfx"
    compileSdk = 34
    
    defaultConfig {
        applicationId = "com.zenhub.gfx"
        minSdk = 21
        targetSdk = 34
        versionCode = 45
        versionName = "2.2.0"
        
        buildConfigField("String", "SDK_KEY", "\"${anyIpProperties["SDK_KEY"]}\"")
        buildConfigField("Boolean", "SEMAPHORE_ENABLED", anyIpProperties["SEMAPHORE_ENABLED"] as String)
        
        vectorDrawables { 
            useSupportLibrary = true
        }
        
        useLibrary("org.apache.http.legacy")
    }
    
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        
        isCoreLibraryDesugaringEnabled = true
    }
    
    signingConfigs {
        getByName("debug") {
            storeFile = file("keystore.jks")
            storePassword = "francispogi"
            keyAlias = "francispogi"
            keyPassword = "francispogi"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    
    viewBinding {
        enable = true
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {

    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))

    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.appcompat:appcompat:1.6.0")

    implementation("androidx.documentfile:documentfile:1.1.0-alpha01")
    
    implementation("com.android.volley:volley:1.2.1")
    
    implementation("com.google.code.gson:gson:2.10.1")
    implementation("com.google.guava:guava:33.0.0-jre")
    
    implementation("androidx.concurrent:concurrent-futures:1.2.0")
    
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.blankj:utilcodex:1.31.1")
    implementation("de.hdodenhof:circleimageview:3.1.0")
    
    implementation("com.google.android.play:app-update:2.1.0")
    
    implementation("com.google.android.gms:play-services-ads:23.1.0")
    implementation("com.google.android.ads.consent:consent-library:1.0.8")
    
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.7.1")
    
    var lifecycle_version = "2.3.1"
   implementation("androidx.lifecycle:lifecycle-process:$lifecycle_version")
   implementation("androidx.lifecycle:lifecycle-runtime:$lifecycle_version")
   annotationProcessor("androidx.lifecycle:lifecycle-compiler:$lifecycle_version")

    
    var glide_version = "4.16.0"
    implementation("com.github.bumptech.glide:glide:$glide_version")
    annotationProcessor("com.github.bumptech.glide:compiler:$glide_version")
    
    val shizuku_version = "13.1.5"
    implementation("dev.rikka.shizuku:api:$shizuku_version")
    implementation("dev.rikka.shizuku:provider:$shizuku_version")
    
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    
    implementation(project(":pagination"))
    implementation(project(":autoimageslider"))
    
    // uses some methods like `transferTo` are only available from Android 13 onwards
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
